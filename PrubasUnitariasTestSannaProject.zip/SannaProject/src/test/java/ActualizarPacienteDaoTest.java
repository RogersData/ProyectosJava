/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import Dao.ActualizarPacienteDao;
import Model.PacienteModel;
import java.sql.Date;
import org.junit.Test;
import static org.junit.Assert.*;

public class ActualizarPacienteDaoTest {
    
     @Test
    public void testObtenerPacientePorDniExistente() {
        ActualizarPacienteDao dao = new ActualizarPacienteDao();
        
        PacienteModel paciente = dao.obtenerPacientePorDni("12345678");

        assertNotNull("❌ No se encontró paciente con DNI válido", paciente);

        // Validar algunos campos conocidos (opcional, si tienes datos exactos)
        assertEquals("999111222", paciente.getTelefono()); // o usa nombres, apellidos si es más confiable
        System.out.println("✅ Paciente obtenido: " + paciente.getNombres());
    }

    @Test
    public void testObtenerPacientePorDniInexistente() {
        ActualizarPacienteDao dao = new ActualizarPacienteDao();
        PacienteModel paciente = dao.obtenerPacientePorDni("99999999"); // DNI que no debe existir
        assertNull("❌ Se obtuvo un paciente aunque el DNI no existe", paciente);
        System.out.println("✅ No se encontró paciente con DNI inexistente (correcto).");
    }
    @Test
    public void testActualizarPacienteExistente() {
        ActualizarPacienteDao dao = new ActualizarPacienteDao();// Este paciente debe existir en tu BD (verifica el ID real)
        PacienteModel paciente = new PacienteModel();
        paciente.setId_paciente(1); // Reemplaza por un ID válido
        paciente.setNombres("Juan Actualizado");
        paciente.setApellidos("Pérez");
        paciente.setFecha_nacimiento(Date.valueOf("1995-01-01"));
        paciente.setSexo("M");
        paciente.setDireccion("Av. Test 123");
        paciente.setTelefono("987654321");
        paciente.setEmail("juan.actualizado@mail.com");
        boolean resultado = dao.actualizarPaciente(paciente);
        assertTrue("❌ La actualización del paciente debería ser exitosa", resultado);
        System.out.println("✅ Paciente actualizado correctamente.");
    }
    @Test
    public void testActualizarPacienteInexistente() {
        ActualizarPacienteDao dao = new ActualizarPacienteDao(); // ID de paciente que no existe
        PacienteModel paciente = new PacienteModel();
        paciente.setId_paciente(9999); // ID no válido
        paciente.setNombres("Inexistente");
        paciente.setApellidos("Prueba");
        paciente.setFecha_nacimiento(Date.valueOf("2000-12-12"));
        paciente.setSexo("F");
        paciente.setDireccion("Sin Dirección");
        paciente.setTelefono("000000000");
        paciente.setEmail("inexistente@test.com");
        boolean resultado = dao.actualizarPaciente(paciente);
        assertFalse("❌ La actualización debería fallar para un paciente inexistente", resultado);
        System.out.println("✅ El paciente no fue actualizado porque no existe (correcto).");
    }
   
    
}
