/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import Dao.CitasDisponiblesDao;
import Model.DisponibilidadMedicaModel;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class CitasDisponiblesDaoTest {
     @Test
    public void testListarCitasDisponiblesConParametrosValidos() {
        CitasDisponiblesDao dao = new CitasDisponiblesDao();
        int idSede = 1;            // Idsede
        int idEspecialidad = 1;    // Idespecialidad
        int idMedico = 1;          //IdMedico
        List<DisponibilidadMedicaModel> citas = dao.listarCitasDisponiblesConSede(idSede, idEspecialidad, idMedico);
        assertNotNull("❌ La lista no debe ser nula", citas);
        assertFalse("❌ Debe haber al menos una cita disponible", citas.isEmpty());
        System.out.println("✅ Citas disponibles encontradas: " + citas.size());
    }
    @Test
    public void testListarCitasDisponiblesConParametrosInvalidos() {
        CitasDisponiblesDao dao = new CitasDisponiblesDao();
        int idSede = 999;          // ID inválido
        int idEspecialidad = 999;
        int idMedico = 999;

        List<DisponibilidadMedicaModel> citas = dao.listarCitasDisponiblesConSede(idSede, idEspecialidad, idMedico);

        assertNotNull("❌ La lista no debe ser nula incluso con datos inválidos", citas);
        assertTrue("✅ La lista debe estar vacía para parámetros inválidos", citas.isEmpty());
    }

    @Test
    public void testEliminarCitaDisponiblePorIdExistente() {
        CitasDisponiblesDao dao = new CitasDisponiblesDao();
        int idCita = 2; 

        boolean eliminado = dao.eliminarCitaDisponiblePorId(idCita);
        assertTrue("❌ La cita con ID válido debería eliminarse", eliminado);
        System.out.println("✅ Cita eliminada correctamente con ID: " + idCita);
    }

    @Test
    public void testEliminarCitaDisponiblePorIdInexistente() {
        CitasDisponiblesDao dao = new CitasDisponiblesDao();
        int idCita = 9999; // ID que no existe

        boolean eliminado = dao.eliminarCitaDisponiblePorId(idCita);
        assertFalse("✅ No se debe eliminar ninguna cita si el ID no existe", eliminado);
    }
}
