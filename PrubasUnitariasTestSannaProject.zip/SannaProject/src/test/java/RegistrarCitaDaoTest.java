/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import Dao.RegistrarCitaDao;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import org.junit.Test;
import static org.junit.Assert.*;
 /***
 * @author Mel
 */
public class RegistrarCitaDaoTest {
     @Test
    public void testRegistrarCitaMedica() {
        RegistrarCitaDao dao = new RegistrarCitaDao();

        int idPaciente = 1;     
        int idMedico = 1;       
        int sedeId = 1;         // Sede válida
        Timestamp fechaCita = Timestamp.valueOf(LocalDateTime.now().plusDays(1)); 
        String motivo = "Consulta general de prueba";

        boolean resultado = dao.registrarCitaMedica(idPaciente, idMedico, sedeId, fechaCita, motivo);

        assertTrue("La cita médica debe registrarse correctamente", resultado);
    }
    
}
