
import Dao.HistorialClinicoDao;
import Model.CitasMedicaModelPacienteModel;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;
/**
 * @author Mel
 */
public class HistorialClinicoDaoTest {
        @Test
    public void testListarCitasPorPacienteExistente() {
        HistorialClinicoDao dao = new HistorialClinicoDao();
        int pacienteIdValido = 1; // ID BD

        List<CitasMedicaModelPacienteModel> citas = dao.listarCitasPorPaciente(pacienteIdValido);

        assertNotNull("❌ La lista de citas no debe ser nula", citas);
        assertFalse("❌ Se esperaba al menos una cita para el paciente", citas.isEmpty());

        for (CitasMedicaModelPacienteModel cita : citas) {
            assertNotNull("❌ El nombre del paciente no debe ser nulo", cita.getNombrePaciente());
            assertNotNull("❌ El nombre del médico no debe ser nulo", cita.getNombreMedico());
            assertNotNull("❌ La especialidad no debe ser nula", cita.getEspecialidadNombre());
            assertNotNull("❌ El estado no debe ser nulo", cita.getEstado());
            assertNotNull("❌ La fecha de cita no debe ser nula", cita.getFechaCita());
        }
    }
    @Test
    public void testListarCitasPorPacienteInexistente() {
        HistorialClinicoDao dao = new HistorialClinicoDao();
        int pacienteIdInvalido = 9999;
        List<CitasMedicaModelPacienteModel> citas = dao.listarCitasPorPaciente(pacienteIdInvalido);
        assertNotNull("❌ La lista no debe ser nula", citas);
        assertTrue("✅ La lista debe estar vacía si el paciente no tiene citas", citas.isEmpty());
    }
}
