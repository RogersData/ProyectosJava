/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import Dao.DoctoresDao;
import Model.DoctorModel;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;
public class DoctoresDaoTest {
    
    @Test
    public void testObtenerDoctoresPorEspecialidadYSede() {
        DoctoresDao dao = new DoctoresDao();
        
        int especialidadId = 1; // ID de especialidad existente
        int sedeId = 1;         // ID de sede existente

        List<DoctorModel> doctores = dao.obtenerDoctoresPorEspecialidadYSede(especialidadId, sedeId);

        assertNotNull("La lista de doctores no debe ser nula", doctores);

       
      
       
    }
   
    
}
