/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import Dao.RegistroPacienteDao;
import Model.UsuarioModel;
import Model.PacienteModel;
import java.sql.Date;
import java.time.LocalDate;
import org.junit.Test;
import static org.junit.Assert.*;

public class RegistroPacienteDaoTest {
    @Test
    public void testRegistrarUsuarioYPaciente() throws Exception {
        RegistroPacienteDao dao = new RegistroPacienteDao();

        // Creación usuario de prueba
        UsuarioModel usuario = new UsuarioModel();
        usuario.setDni("99999998"); // DNI QUE NO ESTE EN LA BD
        usuario.setClave("clave123");

        // Creacion paciente de prueba
        PacienteModel paciente = new PacienteModel();
        paciente.setNombres("PacienteTest");
        paciente.setApellidos("Demo");
        paciente.setFecha_nacimiento(Date.valueOf(LocalDate.of(2000, 1, 1)));
        paciente.setSexo("M");
        paciente.setDireccion("Calle Falsa 123");
        paciente.setTelefono("123456789");
        paciente.setEmail("paciente@demo.com");

        boolean resultado = dao.registrarUsuarioYPaciente(usuario, paciente);

        assertTrue("El usuario y paciente deben registrarse correctamente", resultado);
    }
}
