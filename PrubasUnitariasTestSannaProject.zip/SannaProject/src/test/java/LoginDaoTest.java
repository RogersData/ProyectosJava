/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import Dao.LoginDao;
import Model.UsuarioModel;
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginDaoTest {
     @Test
    public void testValidarLoginCorrecto() throws Exception {
        LoginDao dao = new LoginDao();
        UsuarioModel usuario = new UsuarioModel();
        usuario.setDni("12345678");  //
        usuario.setClave("123"); // 
        int resultado = dao.validarLogin(usuario);
        assertTrue("El login debe ser válido", resultado > 0);
    }
    @Test
    public void testValidarLoginIncorrecto() throws Exception {
        LoginDao dao = new LoginDao();
        UsuarioModel usuario = new UsuarioModel();
        usuario.setDni("00000000");  // 
        usuario.setClave("claveIncorrecta");
        int resultado = dao.validarLogin(usuario);
        assertEquals("El login no debe ser válido", 0, resultado);
    }
    @Test
    public void testObtenerIdUsuarioPorDni() throws Exception {
        LoginDao dao = new LoginDao();
        String dni = "12345678"; //

        int idUsuario = dao.obtenerIdUsuarioPorDni(dni);

        assertTrue("El ID de usuario debe ser mayor que 0", idUsuario > 0);
    }

    @Test
    public void testObtenerIdPacientePorIdUsuario() throws Exception {
        LoginDao dao = new LoginDao();
        int idUsuario = 1; //ID BD

        int idPaciente = dao.obtenerIdPacientePorIdUsuario(idUsuario);

        assertTrue("El ID del paciente debe ser mayor que 0", idPaciente > 0);
    }
}
