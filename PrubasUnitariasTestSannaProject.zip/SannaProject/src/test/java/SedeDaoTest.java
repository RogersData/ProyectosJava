/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import Dao.SedeDao;
import Model.SedeModel;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;
public class SedeDaoTest {
     @Test
    public void testObtenerTodasLasSedes() {
        SedeDao dao = new SedeDao();

        List<SedeModel> sedes = dao.obtenerTodasLasSedes();

        assertNotNull("La lista de sedes no debe ser nula", sedes);

        // Puedes descomentar esta línea si sabes que la tabla no está vacía
        // assertFalse("Se esperaba al menos una sede en la base de datos", sedes.isEmpty());

        // Solo para visualización (opcional)
        for (SedeModel sede : sedes) {
            System.err.println("ID: " + sede.getSede_id() + " - Nombre: " + sede.getNombre());
        }
    }
}
