/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import Dao.CancelarCitasDao;
import Model.CitasMedicaModelPacienteModel;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class CancelarCitasDaoTest {
    @Test
    public void testListarCitasPendientesYConfirmadasPorPacienteExistente() {
        CancelarCitasDao dao = new CancelarCitasDao();

        int idPaciente = 1; 
        List<CitasMedicaModelPacienteModel> citas = dao.listarCitasPendientesYConfirmadasPorPaciente(idPaciente);
        assertNotNull("La lista no debe ser nula", citas);
        // El test pasa si encuentra al menos una cita (opcional)
        System.out.println("✅ Citas encontradas: " + citas.size());
    }
    @Test
    public void testListarCitasPendientesYConfirmadasPorPacienteInexistente() {
        CancelarCitasDao dao = new CancelarCitasDao();
        int idPacienteInexistente = 9999; // ID de paciente que no exista
        List<CitasMedicaModelPacienteModel> citas = dao.listarCitasPendientesYConfirmadasPorPaciente(idPacienteInexistente);
        assertNotNull("La lista no debe ser nula incluso si no hay resultados", citas);
        assertTrue("La lista debe estar vacía si el paciente no tiene citas", citas.isEmpty());
        System.out.println("✅ Lista vacía correctamente para paciente inexistente.");
    }

    @Test
    public void testCancelarCitaPorIdExistente() {
        CancelarCitasDao dao = new CancelarCitasDao();

        int idCita =3 ; // Cambia por una cita válida con estado Pendiente o Confirmada
        boolean resultado = dao.cancelarCitaPorId(idCita);

        assertTrue("La cita debe ser cancelada exitosamente", resultado);
        System.out.println("✅ Cita cancelada correctamente.");
    }

    @Test
    public void testCancelarCitaPorIdInexistente() {
        CancelarCitasDao dao = new CancelarCitasDao();

        int idCitaInvalido = 9999; // ID que no exista
        boolean resultado = dao.cancelarCitaPorId(idCitaInvalido);

        assertFalse("No debe cancelar si la cita no existe o ya está cancelada", resultado);
        System.out.println("✅ No se canceló la cita (correcto, no existía o ya estaba cancelada).");
    }
}
