/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import Dao.EspecialidadDao;
import Model.EspecialidadModel;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;
public class EspecialidadDaoTest {
     @Test
    public void testObtenerEspecialidadesPorSedeConResultados() {
        EspecialidadDao dao = new EspecialidadDao();
        int sedeId = 1; // ID

        List<EspecialidadModel> especialidades = dao.obtenerEspecialidadesPorSede(sedeId);

        assertNotNull("La lista de especialidades no debe ser nula", especialidades);

        
        for (EspecialidadModel esp : especialidades) {
            System.err.println("ID: " + esp.getId_especialidad() + " - Nombre: " + esp.getNombre_especialidad());
        }
    }

    @Test
    public void testObtenerEspecialidadesPorSedeSinResultados() {
        EspecialidadDao dao = new EspecialidadDao();
        int sedeId = 9999; // ID QUE NO EXISTE

        List<EspecialidadModel> especialidades = dao.obtenerEspecialidadesPorSede(sedeId);

        assertNotNull("La lista no debe ser nula aunque no haya resultados", especialidades);
        assertTrue("Se esperaba lista vacía para sede sin especialidades", especialidades.isEmpty());
    }
        
   
    
}
