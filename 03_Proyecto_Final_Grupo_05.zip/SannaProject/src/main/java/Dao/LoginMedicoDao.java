/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import BD.conexionBD;
import Model.UsuarioModel;
import java.sql.ResultSet;

/**
 * DAO para login de médicos
 */
public class LoginMedicoDao {

    int rspta = 0;
    String sql = "";
    ResultSet rs = null;
    conexionBD cn = new conexionBD();

    public int validarLoginMedico(UsuarioModel tm) throws Exception {
        sql = "SELECT COUNT(id_usuario) AS cantidad FROM Usuarios "
            + "WHERE dni = '" + tm.getDni() + "' "
            + "AND clave = '" + tm.getClave() + "' "
            + "AND rol = 'Medico'";

        rs = cn.ejecutarConsulta(sql);
        while (rs.next()) {
            rspta = rs.getInt("cantidad");
        }
        return rspta;
    }

    public int obtenerIdUsuarioPorDni(String dni) throws Exception {
        int idUsuario = 0;
        sql = "SELECT id_usuario FROM Usuarios WHERE dni = '" + dni + "'";
        rs = cn.ejecutarConsulta(sql);
        if (rs.next()) {
            idUsuario = rs.getInt("id_usuario");
        }
        return idUsuario;
    }
}

