/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import BD.conexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Mel
 */
public class ConseguirDoctor {
    
    public String buscarMedicoPorDni(String dni) throws SQLException {
        String medico = "";
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        con = conexionBD.conectar();
        // Paso 1: Obtener el id_usuario desde el dni
        String sqlUsuario = "SELECT id_usuario FROM Usuarios WHERE dni = ?";
        ps = con.prepareStatement(sqlUsuario);
        ps.setString(1, dni);
        rs = ps.executeQuery();
        int idUsuario = -1;
        if (rs.next()) {
            idUsuario = rs.getInt("id_usuario");
        } else {
            return "❌ No se encontró un usuario con ese DNI.";
        }
        rs.close();
        ps.close();
        // Paso 2: Buscar datos del médico con ese id_usuario
        String sqlMedico = "SELECT m.id_medico, m.nombres, m.apellidos, m.telefono, m.email, " +
                "e.nombre_especialidad " +
                "FROM Medicos m " +
                "LEFT JOIN Especialidades e ON m.especialidad_id = e.id_especialidad " +
                "WHERE m.id_usuario = ?";
        ps = con.prepareStatement(sqlMedico);
        ps.setInt(1, idUsuario);
        rs = ps.executeQuery();
        if (rs.next()) {
            medico = "ID Médico: " + rs.getInt("id_medico") +
                    ", Nombres: " + rs.getString("nombres") +
                    ", Apellidos: " + rs.getString("apellidos") +
                    ", Teléfono: " + rs.getString("telefono") +
                    ", Email: " + rs.getString("email") +
                    ", Especialidad: " + rs.getString("nombre_especialidad");
        } else {
            medico = "❌ El usuario no está registrado como médico.";
        }
        if (rs != null) rs.close();
        if (ps != null) ps.close();
        if (con != null) con.close();

        return medico;
    }
    
}
