/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import BD.conexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Mel
 */
public class actulizarDoctor {
    
    public boolean actualizarContactoMedico(int idMedico, String telefono, String email) throws SQLException {
        Connection con = null;
        PreparedStatement ps = null;
        boolean actualizado = false;

        try {
            con = conexionBD.conectar();

            String sql = "UPDATE Medicos SET telefono = ?, email = ? WHERE id_medico = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, telefono);
            ps.setString(2, email);
            ps.setInt(3, idMedico);

            int filas = ps.executeUpdate();
            actualizado = (filas > 0);

        } catch (SQLException e) {
            System.err.println("❌ Error al actualizar contacto del médico: " + e.getMessage());
            throw e;
        } finally {
            if (ps != null) ps.close();
            if (con != null) con.close();
        }

        return actualizado;
    }
    
}
