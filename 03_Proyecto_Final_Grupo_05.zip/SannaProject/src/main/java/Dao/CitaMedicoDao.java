/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Model.CitaMedicoModel;
import java.sql.*;
import java.util.*;

public class CitaMedicoDao {

    private final String URL = "jdbc:mysql://localhost:3306/SANABD";
    private final String USER = "root";
    private final String PASS = ""; // Ajusta tu contraseña

    public List<CitaMedicoModel> obtenerCitasPorDni(String dniMedico) {
        List<CitaMedicoModel> lista = new ArrayList<>();

        String sql = "SELECT cm.id AS id_cita, " +
                     "p.nombres AS nombre_paciente, p.apellidos AS apellido_paciente, " +
                     "m.nombres AS nombre_medico, m.apellidos AS apellido_medico, " +
                     "esp.nombre_especialidad AS especialidad, cm.fecha_cita, cm.estado " +
                     "FROM citas_medicas cm " +
                     "INNER JOIN pacientes p ON cm.id_paciente = p.id_paciente " +
                     "INNER JOIN medicos m ON cm.id_medico = m.id_medico " +
                     "INNER JOIN usuarios u ON m.id_usuario = u.id_usuario " +
                     "INNER JOIN especialidades esp ON m.especialidad_id = esp.id_especialidad " +
                     "WHERE u.dni = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, dniMedico);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                CitaMedicoModel cita = new CitaMedicoModel();
                cita.setIdCita(rs.getInt("id_cita"));
                cita.setNombrePaciente(rs.getString("nombre_paciente"));
                cita.setApellidoPaciente(rs.getString("apellido_paciente"));
                cita.setNombreMedico(rs.getString("nombre_medico"));
                cita.setApellidoMedico(rs.getString("apellido_medico"));
                cita.setEspecialidad(rs.getString("especialidad"));
                cita.setFechaCita(rs.getTimestamp("fecha_cita"));
                cita.setEstado(rs.getString("estado"));

                lista.add(cita);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
}
