/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import BD.conexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Mel
 */
public class filtradoPorDniPaceinte {

    public List<String> buscarCitasPorDni(String dni) {
        List<String> citas = new ArrayList<>();
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            // ✅ Usamos el método correcto de conexión
            con = conexionBD.conectar();

            // Paso 1: Buscar el id_usuario por DNI
            String sqlUsuario = "SELECT id_usuario FROM Usuarios WHERE dni = ?";
            ps = con.prepareStatement(sqlUsuario);
            ps.setString(1, dni);
            rs = ps.executeQuery();

            int idUsuario = -1;
            if (rs.next()) {
                idUsuario = rs.getInt("id_usuario");
            } else {
                return citas; // DNI no existe
            }

            rs.close();
            ps.close();

            // Paso 2: Buscar citas médicas usando id_usuario como id_paciente
            String sqlCitas = "SELECT fecha_cita, motivo, estado, fecha_registro " +
                              "FROM citas_medicas WHERE id_paciente = ? ORDER BY fecha_cita DESC";

            ps = con.prepareStatement(sqlCitas);
            ps.setInt(1, idUsuario);
            rs = ps.executeQuery();

            while (rs.next()) {
                String cita = "Fecha: " + rs.getTimestamp("fecha_cita") +
                              ", Motivo: " + rs.getString("motivo") +
                              ", Estado: " + rs.getString("estado") +
                              ", Registrada: " + rs.getTimestamp("fecha_registro");
                citas.add(cita);
            }

            System.out.println("✅ Consulta realizada correctamente.");

        } catch (SQLException e) {
            System.err.println("❌ Error en la búsqueda: " + e.getMessage());
        } finally {
            try { if (rs != null) rs.close(); } catch (SQLException e) {}
            try { if (ps != null) ps.close(); } catch (SQLException e) {}
            try { if (con != null) con.close(); } catch (SQLException e) {}
        }

        return citas;
    }
    
    
    
    
}
