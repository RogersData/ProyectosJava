/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import BD.conexionBD;
import Model.UsuarioModel;
import java.sql.ResultSet;
/**
 *
 * @author USUARIO
 */
public class LoginAdministradorDao {
    
	  int rspta=0;
    String sql="";
    ResultSet rs=null;
    conexionBD cn=new conexionBD();
    
public int validarLoginAdministrador(UsuarioModel tm) throws Exception {
 
     sql = "SELECT COUNT(id_usuario) AS cantidad FROM Usuarios "
               + "WHERE dni = '" + tm.getDni() + "' "
               + "AND clave = '" + tm.getClave() + "' "
               + "AND rol = 'Administrador'";
    
    rs = cn.ejecutarConsulta(sql);
    while (rs.next()) {
        rspta = rs.getInt("cantidad");
    }
    return rspta;
}


	public int obtenerIdUsuarioPorDni(String dni) throws Exception {
    int idUsuario = 0;
     sql = "SELECT id_usuario FROM Usuarios WHERE dni = '" + dni + "'";
     rs = cn.ejecutarConsulta(sql);
    if (rs.next()) {
        idUsuario = rs.getInt("id_usuario");
    }
    return idUsuario;
}
	
	
public int obtenerIdPacientePorIdUsuario(int idUsuario) throws Exception {
    int idPaciente = 0;
     sql = "SELECT id_paciente FROM Pacientes WHERE id_usuario = " + idUsuario;
     rs = cn.ejecutarConsulta(sql);
    if (rs.next()) {
        idPaciente = rs.getInt("id_paciente");
    }
    rs.close();
    return idPaciente;
}


  // Nuevo método que imprime el resultado del login
    public void imprimirResultadoLogin(UsuarioModel tm) {
        try {
            int resultado = validarLoginAdministrador(tm);
            if (resultado > 0) {
                System.out.println("✅ Usuario administrador válido encontrado.");
            } else {
                System.out.println("❌ No se encontró usuario administrador con esas credenciales.");
            }
        } catch (Exception e) {
            System.err.println("⚠️ Error al validar el login: " + e.getMessage());
            e.printStackTrace();
        }
    }
	
	
    public static void main(String[] args) {
        UsuarioModel user = new UsuarioModel();
        user.setDni("98746356");
        user.setClave("123");

        LoginAdministradorDao dao = new LoginAdministradorDao();
        dao.imprimirResultadoLogin(user);
    }
    
    
}

