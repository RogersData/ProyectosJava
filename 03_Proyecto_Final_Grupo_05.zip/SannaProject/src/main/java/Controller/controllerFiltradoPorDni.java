/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Dao.filtradoPorDniPaceinte;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Mel
 */

@WebServlet(name = "filtradoPorDni", urlPatterns = {"/filtradoPorDni"})
public class controllerFiltradoPorDni extends HttpServlet{
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Obtener DNI desde el formulario JSP
        String dni = request.getParameter("dni");

        // Validación básica
        if (dni != null && !dni.trim().isEmpty()) {
            // Llama al DAO para buscar las citas
            filtradoPorDniPaceinte dao = new filtradoPorDniPaceinte();
            List<String> citas = dao.buscarCitasPorDni(dni);

            // Pasar la lista al JSP
            request.setAttribute("citas", citas);
            request.setAttribute("dni", dni);
        }

        // Enviar la petición al JSP de resultado
        request.getRequestDispatcher("filtrarDni.jsp").forward(request, response);
    }
    
}
