/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Dao.ConseguirDoctor;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Mel
 */
@WebServlet(name = "BuscarMedicoController", urlPatterns = {"/BuscarMedicoController"})
public class BuscarMedicoController extends HttpServlet{
    
    
    
   @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String dni = request.getParameter("dni");
        ConseguirDoctor dao = new ConseguirDoctor();

        try {
            String resultado = dao.buscarMedicoPorDni(dni);
            request.setAttribute("resultado", resultado); // 👈 mandamos cadena
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("resultado", "❌ Error al buscar: " + e.getMessage());
        }

        request.getRequestDispatcher("buscarActualizarMedico.jsp").forward(request, response);
    }
    
}
