/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Dao.LoginAdministradorDao;
import Model.UsuarioModel;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpSession;
/**
 *
 * @author USUARIO
 */
@WebServlet(name = "LoginAdministradorController", urlPatterns = {"/LoginAdministradorController"})
public class LoginAdministradorController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
		// 1. Obtener datos del formulario
        String dni = request.getParameter("txtdniAdministrador");
        String clave = request.getParameter("txtclaveAdministrador");

        // 2. Preparar el modelo
        UsuarioModel admin = new UsuarioModel();
        admin.setDni(dni);
        admin.setClave(clave);

        // 3. DAO para login
        LoginAdministradorDao dao = new LoginAdministradorDao();
        try {
            int valido = dao.validarLoginAdministrador(admin);
            if (valido > 0) {
                int idUsuario = dao.obtenerIdUsuarioPorDni(dni);

                // 4. Crear sesión
                HttpSession session = request.getSession();
                session.setAttribute("idAdministrador", idUsuario);
                session.setAttribute("dniAdministrador", dni);

                // 5. Redirigir al panel de administrador
                response.sendRedirect("menuAdministrador.jsp");

            } else {
                // Usuario no válido
                request.setAttribute("errorLogin", "Credenciales inválidas o no tiene rol de administrador.");
                request.getRequestDispatcher("loginAdministrador.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorLogin", "Error en el sistema: " + e.getMessage());
            request.getRequestDispatcher("loginAdministrador.jsp").forward(request, response);
        }
		
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
