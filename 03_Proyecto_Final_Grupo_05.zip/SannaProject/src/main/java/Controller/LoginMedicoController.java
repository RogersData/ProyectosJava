/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import Dao.LoginMedicoDao;
import Model.UsuarioModel;

/**
 * Servlet para login de médicos
 */
@WebServlet(name = "LoginMedicoController", urlPatterns = {"/LoginMedicoController"})
public class LoginMedicoController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String dni = request.getParameter("txtdniMedico");
        String clave = request.getParameter("txtclaveMedico");

        UsuarioModel medico = new UsuarioModel();
        medico.setDni(dni);
        medico.setClave(clave);

        LoginMedicoDao dao = new LoginMedicoDao();
        try {
            int valido = dao.validarLoginMedico(medico);
            if (valido > 0) {
                int idUsuario = dao.obtenerIdUsuarioPorDni(dni);

                HttpSession session = request.getSession();
                session.setAttribute("idMedico", idUsuario);
                session.setAttribute("dniMedico", dni);

                response.sendRedirect("menuMedico.jsp");

            } else {
                request.setAttribute("errorLogin", "Credenciales inválidas o no tiene rol de médico.");
                request.getRequestDispatcher("loginMedico.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorLogin", "Error en el sistema: " + e.getMessage());
            request.getRequestDispatcher("loginMedico.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Login de Médico";
    }
}

