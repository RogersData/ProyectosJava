/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Dao.ConseguirDoctor;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Mel
 */
@WebServlet(name = "PerfilMedicoController", urlPatterns = {"/PerfilMedicoController"})
public class PerfilMedicoController extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        // Recuperar el dni de la sesión
        HttpSession session = request.getSession();
        String dniMedico = (String) session.getAttribute("dniMedico");

        if (dniMedico == null) {
            response.sendRedirect("loginMedico.jsp");
            return;
        }

        // Llamar al método para conseguir datos del médico
        ConseguirDoctor conseguir = new ConseguirDoctor();
        try {
            String datosMedico = conseguir.buscarMedicoPorDni(dniMedico);

            request.setAttribute("infoMedico", datosMedico);
            request.getRequestDispatcher("perfilMedico.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Error al cargar datos del médico: " + e.getMessage());
            request.getRequestDispatcher("menuMedico.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(PerfilMedicoController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(PerfilMedicoController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
