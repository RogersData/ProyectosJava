/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import Dao.CancelarCitasDao;
import Dao.HistorialClinicoDao;
import Model.CitasMedicaModelPacienteModel;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author USUARIO
 */
@WebServlet(name = "CitaCancelarController", urlPatterns = {"/CitaCancelarController"})
public class CitaCancelarController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

         response.setContentType("text/html;charset=UTF-8");

    HttpSession session = request.getSession();
    Integer idPaciente = (Integer) session.getAttribute("idPacienteOriginal");

    if (idPaciente == null) {
        request.setAttribute("error", "ID del paciente no proporcionado.");
        request.getRequestDispatcher("error.jsp").forward(request, response);
        return;
    }

    int idPacienteInt = idPaciente.intValue();
    CancelarCitasDao dao = new CancelarCitasDao();

   
    String idCitaStr = request.getParameter("idCita");
    if (idCitaStr != null && !idCitaStr.isEmpty()) {
        try {
            int idCita = Integer.parseInt(idCitaStr);
            boolean eliminado = dao.cancelarCitaPorId(idCita);

            if (eliminado) {
                request.setAttribute("mensaje", "Cita cancelada correctamente.");
            } else {
                request.setAttribute("error", "No se pudo cancelar la cita. Verifica el ID.");
            }
        } catch (NumberFormatException e) {
            request.setAttribute("error", "ID de cita inválido.");
        }
    }
    

   
    List<CitasMedicaModelPacienteModel> historial = dao.listarCitasPendientesYConfirmadasPorPaciente(idPacienteInt);
    request.setAttribute("historialCitaCancelar", historial);

  request.setAttribute("citaCancelada", true);
request.getRequestDispatcher("citasRegistradas.jsp").forward(request, response);
		
		
		
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
