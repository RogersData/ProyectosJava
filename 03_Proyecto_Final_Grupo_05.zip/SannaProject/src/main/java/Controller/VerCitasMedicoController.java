/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Dao.CitaMedicoDao;
import Model.CitaMedicoModel;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "VerCitasMedicoController", urlPatterns = {"/VerCitasMedicoController"})
public class VerCitasMedicoController extends HttpServlet {
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String dniMedico = (String) session.getAttribute("dniMedico");

        if (dniMedico != null) {
            CitaMedicoDao dao = new CitaMedicoDao();
            List<CitaMedicoModel> citas = dao.obtenerCitasPorDni(dniMedico);

            request.setAttribute("listaCitas", citas);
            request.getRequestDispatcher("verCitasMedico.jsp").forward(request, response);
        } else {
            response.sendRedirect("loginMedico.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}

