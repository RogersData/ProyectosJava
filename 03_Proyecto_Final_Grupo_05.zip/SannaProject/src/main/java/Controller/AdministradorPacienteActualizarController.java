/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import Dao.ActualizarPacienteDao;
import Model.PacienteModel;
import java.io.IOException;
import java.sql.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author USUARIO
 */
@WebServlet(name = "AdministradorPacienteActualizarController", urlPatterns = {"/AdministradorPacienteActualizarController"})
public class AdministradorPacienteActualizarController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
         // Verifica el método de la solicitud
        String method = request.getMethod();
        ActualizarPacienteDao dao = new ActualizarPacienteDao();

        if (method.equalsIgnoreCase("GET")) {
            // ----------------------
            // BUSCAR PACIENTE POR DNI
            // ----------------------
            String dni = request.getParameter("dni");

            if (dni != null && !dni.trim().isEmpty()) {
                PacienteModel paciente = dao.obtenerPacientePorDniv2(dni);

                if (paciente != null) {
                    request.setAttribute("pacienteEncontrado", paciente);
                } else {
                    request.setAttribute("mensajeError", "No se encontró paciente con DNI: " + dni);
                }
            }

        } else if (method.equalsIgnoreCase("POST")) {
            // ----------------------------
            // ACTUALIZAR DATOS DEL PACIENTE
            // ----------------------------
            try {
                // Recuperar datos del formulario
                String dni = request.getParameter("dni");
                String nombres = request.getParameter("nombres");
                String apellidos = request.getParameter("apellidos");
                String fechaNacimientoStr = request.getParameter("fechaNacimiento");
                String sexo = request.getParameter("sexo");
                String telefono = request.getParameter("telefono");
                String direccion = request.getParameter("direccion");
                String correo = request.getParameter("correo");

                // Buscar el paciente para obtener su ID
                PacienteModel paciente = dao.obtenerPacientePorDniv2(dni);

                if (paciente != null) {
                    // Actualizar con los nuevos datos
                    paciente.setNombres(nombres);
                    paciente.setApellidos(apellidos);
                    paciente.setFecha_nacimiento(Date.valueOf(fechaNacimientoStr)); // yyyy-MM-dd
                    paciente.setSexo(sexo);
                    paciente.setTelefono(telefono);
                    paciente.setDireccion(direccion);
                    paciente.setEmail(correo);

                    boolean actualizado = dao.actualizarPaciente(paciente);

                    if (actualizado) {
                        // 🔔 MENSAJE DE ÉXITO CLARO
                        request.setAttribute("pacienteEncontrado", paciente);
                        request.setAttribute("mensajeExito", "✅ Paciente actualizado correctamente.");
                    } else {
                        request.setAttribute("mensajeError", "❌ No se pudo actualizar el paciente. Intente nuevamente.");
                    }
                } else {
                    request.setAttribute("mensajeError", "❌ Paciente no encontrado para actualizar.");
                }

            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("mensajeError", "❌ Error al procesar la actualización: " + e.getMessage());
            }
        }

        // Redirigir al JSP
        RequestDispatcher rd = request.getRequestDispatcher("administradorActualizarPaciente.jsp");
        rd.forward(request, response);
		
		
		
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
