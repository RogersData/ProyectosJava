/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import Dao.EspecialidadDao;
import Model.EspecialidadModel;
import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "EspecialidadController", urlPatterns = {"/EspecialidadController"})
public class EspecialidadController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String sedeIdParam = request.getParameter("sedeId");

        try (PrintWriter out = response.getWriter()) {
            if (sedeIdParam != null && !sedeIdParam.isEmpty()) {
                int sedeId = Integer.parseInt(sedeIdParam);

                EspecialidadDao dao = new EspecialidadDao();
                List<EspecialidadModel> especialidades = dao.obtenerEspecialidadesPorSede(sedeId);

                Gson gson = new Gson();
                String json = gson.toJson(especialidades);
                out.print(json);
            } else {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"error\":\"sedeId requerido\"}");
            }
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().print("{\"error\":\"sedeId debe ser un número válido\"}");
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().print("{\"error\":\"Error interno en el servidor\"}");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}

