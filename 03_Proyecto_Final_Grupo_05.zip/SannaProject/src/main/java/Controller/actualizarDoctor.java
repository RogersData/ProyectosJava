/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Dao.actulizarDoctor;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Mel
 */
@WebServlet(name = "ActualizarContactoController", urlPatterns = {"/ActualizarContactoController"})
public class actualizarDoctor extends HttpServlet{
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        int idMedico = Integer.parseInt(request.getParameter("idMedico"));
        String telefono = request.getParameter("telefono");
        String email = request.getParameter("email");

        actulizarDoctor dao = new actulizarDoctor();

        try {
            boolean actualizado = dao.actualizarContactoMedico(idMedico, telefono, email);

            if (actualizado) {
                // ✅ Guardar mensaje en sesión
                HttpSession session = request.getSession();
                session.setAttribute("mensaje", "✅ Datos actualizados correctamente.");
                response.sendRedirect("menuAdministrador.jsp");
                return;
            } else {
                request.setAttribute("resultado", "❌ No se pudo actualizar los datos.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("resultado", "❌ Error: " + e.getMessage());
        }

        request.getRequestDispatcher("buscarActualizarMedico.jsp").forward(request, response);
    }
    
}
