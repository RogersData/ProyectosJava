/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import Dao.CitasDisponiblesDao;
import Dao.RegistrarCitaDao;
import Model.DisponibilidadMedicaModel;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author USUARIO
 */
@WebServlet(name = "RegistrarCitaController", urlPatterns = {"/RegistrarCitaController"})
public class RegistrarCitaController extends HttpServlet {
	
private RegistrarCitaDao registrarCitaDao = new RegistrarCitaDao();
    private CitasDisponiblesDao citasDisponiblesDao = new CitasDisponiblesDao();
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
       
 
 
        HttpSession session = request.getSession(false);
     
        int idPaciente = (int) session.getAttribute("idPacienteOriginal");
        int idSede = (int) session.getAttribute("especialidadId_sedeId");
        int idDoctor = (int) session.getAttribute("especialidadId_doctorId");
        
        
        int idDisponibilidad = (int) session.getAttribute("especialidadId_combobox");
       
       int idDisponibilidadReserva = Integer.parseInt(request.getParameter("idDisponibilidad"));
		
		try {
        
        
            String motivo = request.getParameter("motivo");

           
            String fechaCitaStr = request.getParameter("fechaCita"); // "2025-06-10 08:00"
   DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
LocalDateTime localDateTime = LocalDateTime.parse(fechaCitaStr, formatter);
Timestamp fechaCita = Timestamp.valueOf(localDateTime);

           
            RegistrarCitaDao dao = new RegistrarCitaDao();
            CitasDisponiblesDao daoCitaDispo = new CitasDisponiblesDao();
            
         boolean exitoDispo = daoCitaDispo.eliminarCitaDisponiblePorId(idDisponibilidadReserva);
            
            
            boolean exito = dao.registrarCitaMedica(idPaciente, idDoctor, idSede, fechaCita, motivo);

           
           if (exito) {
    response.sendRedirect("reservarCitaPaciente.jsp?mensaje=exito");
} else {
    response.sendRedirect("reservarCitaPaciente.jsp?mensaje=error");
}

        } catch (Exception e) {
            e.printStackTrace();
    response.sendRedirect("reservarCitaPaciente.jsp?mensaje=error");
        }
		
		
		
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
