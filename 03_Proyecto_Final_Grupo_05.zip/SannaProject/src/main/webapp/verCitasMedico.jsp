<%-- 
    Document   : verCitasMedico
    Created on : 8 jul. 2025, 11:11:38 p. m.
    Author     : Diego
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="Model.CitaMedicoModel"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Mis Citas - Médico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Citas Programadas</h2>
        <table class="table table-bordered table-hover">
            <thead class="table-success">
                <tr>
                    <th>ID Cita</th>
                    <th>Paciente</th>
                    <th>Especialidad</th>
                    <th>Fecha y Hora</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <%
                    List<CitaMedicoModel> citas = (List<CitaMedicoModel>) request.getAttribute("listaCitas");
                    if (citas != null && !citas.isEmpty()) {
                        for (CitaMedicoModel cita : citas) {
                %>
                <tr>
                    <td><%= cita.getIdCita() %></td>
                    <td><%= cita.getNombrePaciente() %> <%= cita.getApellidoPaciente() %></td>
                    <td><%= cita.getEspecialidad() %></td>
                    <td><%= cita.getFechaCita() %></td>
                    <td><%= cita.getEstado() %></td>
                </tr>
                <%
                        }
                    } else {
                %>
                <tr>
                    <td colspan="5" class="text-center">No hay citas registradas.</td>
                </tr>
                <%
                    }
                %>
            </tbody>
        </table>
        <a href="menuMedico.jsp" class="btn btn-secondary">Volver</a>
    </div>
</body>
</html>

