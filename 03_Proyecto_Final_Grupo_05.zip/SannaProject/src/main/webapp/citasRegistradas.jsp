<%-- 
    Document   : citasRegisstradas.jsp
    Created on : 6 jun. 2025, 12:20:54 p. m.
    Author     : USUARIO
--%>

<%@page import="Model.CitasMedicaModelPacienteModel"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Citas Activas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<style>
    .navbar-custom {
        background: linear-gradient(135deg, #4caf50, #2e7d32);
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .nav-link { color: #fff !important; font-weight: 500; transition: all 0.3s ease; }
    .nav-link:hover { color: #dcedc8 !important; }
    .navbar-brand { font-size: 1.5rem; font-weight: bold; color: #ffffff !important; }
    .dropdown-menu { border-radius: 10px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); }
    .dropdown-item:hover { background-color: #f1f8e9; }
    h2 { margin-top: 40px; color: #2e7d32; font-weight: bold; }
    .table-container { margin: 30px auto; max-width: 95%; }

    /* Estados de cita */
   .estado-pendiente {
    background-color: #fff3cd !important;
    color: #856404 !important;
    font-weight: bold;
}
.estado-confirmada, .estado-completada {
    background-color: #d4edda !important;
    color: #155724 !important;
    font-weight: bold;
}
.estado-cancelada {
    background-color: #f8d7da !important;
    color: #721c24 !important;
    font-weight: bold;}

</style>

</head>
<body>
<%-- BLOQUE DE MENSAJES DE ALERTA: ÉXITO Y ERROR --%>
<%
    String mensaje = (String) session.getAttribute("mensaje");
    String error = (String) session.getAttribute("error");

    if (mensaje != null) {
%>
    <div class="container mt-3">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <%= mensaje %>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
<%
        session.removeAttribute("mensaje");
    }

    if (error != null) {
%>
    <div class="container mt-3">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <%= error %>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
<%
        session.removeAttribute("error");
    }
%>
<nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="bi bi-hospital"></i> SANNA</a>
        <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto gap-2">
                <li class="nav-item"><a class="nav-link" href="menuPaciente.jsp"><i class="bi bi-info-circle"></i> Quiénes Somos</a></li>
                <li class="nav-item"><a class="nav-link" href="SedesController"><i class="bi bi-calendar-check"></i> Reservar cita médica</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="citasDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-journal-medical"></i> Mis citas
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="CitaCancelarController"><i class="bi bi-calendar-event"></i> Citas próximas</a></li>
                        <li><a class="dropdown-item" href="HistorialClinicoController"><i class="bi bi-file-earmark-medical"></i> Historial clínico</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="cuentaDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i> Mi cuenta
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="ActualizarPacienteController"><i class="bi bi-person"></i> Perfil</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="login.jsp"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container text-center">
    <h2><i class="bi bi-journal-medical"></i>Citas Activas</h2>
</div>

<div class="table-container">
    <table class="table table-bordered table-hover table-striped">
        <thead class="table-success">
            <tr>
                <th>Nombre y Apellido</th>
                <th>Nombre del Médico</th>
                <th>Especialidad</th>
                <th>Sede</th>
                <th>Fecha de la Cita</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <%
            List<CitasMedicaModelPacienteModel> historial = (List<CitasMedicaModelPacienteModel>) request.getAttribute("historialCitaCancelar");
            if (historial != null && !historial.isEmpty()) {
                for (CitasMedicaModelPacienteModel cita : historial) {
        %>
            <tr>
                <td><%= cita.getNombrePaciente() %> <%= cita.getApellidoPaciente() %></td>
                <td><%= cita.getNombreMedico() %> <%= cita.getApellidoMedico() %></td>
                <td><%= cita.getEspecialidadNombre() %></td>
                <td><%= cita.getNombreSede() %></td>
                <td><%= cita.getFechaCita() %></td>
                <td class="<%= 
                    cita.getEstado().trim().equalsIgnoreCase("Pendiente") ? "estado-pendiente" : 
                    (cita.getEstado().trim().equalsIgnoreCase("Confirmada") ? "estado-confirmada" : 
                    (cita.getEstado().trim().equalsIgnoreCase("Cancelada") ? "estado-cancelada" : 
                    (cita.getEstado().trim().equalsIgnoreCase("Completada") ? "estado-completada" : "")))
                %>">
                    <%= cita.getEstado().trim() %>
                </td>
                <td>
                    <form action="CitaCancelarController" method="post" onsubmit="return confirm('¿Estás seguro de que deseas cancelar esta cita?');">
                        <input type="hidden" name="idCita" value="<%= cita.getIdCita() %>">
                        <button type="button" class="btn btn-sm btn-danger" onclick="abrirModalCancelacion(<%= cita.getIdCita() %>)">
    <i class="bi bi-x-circle"></i> Cancelar
</button>
                    </form>
                </td>
            </tr>
        <%
                }
            } else {
        %>
            <tr>
                <td colspan="7" class="text-center">No se encontraron citas en el historial.</td>
            </tr>
        <%
            }
        %>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
<!-- Modal de confirmación -->
<div class="modal fade" id="confirmarCancelacionModal" tabindex="-1" aria-labelledby="confirmarCancelacionLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-warning text-dark">
        <h5 class="modal-title" id="confirmarCancelacionLabel">¿Confirmar cancelación?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        ¿Estás seguro de que deseas cancelar esta cita médica?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, volver</button>
        <form id="formCancelarCita" method="post" action="CitaCancelarController">
          <input type="hidden" name="idCita" id="inputIdCita">
          <button type="submit" class="btn btn-danger">Sí, cancelar</button>
        </form>
      </div>
    </div>
  </div>
</div>


<script>
  function abrirModalCancelacion(idCita) {
    document.getElementById('inputIdCita').value = idCita;
    var modal = new bootstrap.Modal(document.getElementById('confirmarCancelacionModal'));
    modal.show();
  }
</script>
</body>
</html>
