<%-- 
    Document   : menuPaciente
    Created on : 29 may. 2025, 6:17:07 p. m.
    Author     : USUARIO
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Menu Paciente - Clínica SANNA</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        /* Imagen de fondo con overlay para mejor lectura */
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #fff;
            background: url('https://agendapro.com/web_assets/img/Salud_2_Clinicas.webp') no-repeat center center fixed;
            background-size: cover;
            position: relative;
        }
        /* Capa semitransparente sobre la imagen */
        body::before {
            content: "";
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            z-index: -1;
        }

        /* Tu estilo original del navbar */
        .navbar-custom {
            background: linear-gradient(135deg, #4caf50, #2e7d32);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .nav-link {
            color: #fff !important;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .nav-link:hover {
            color: #dcedc8 !important;
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: #ffffff !important;
        }
        .dropdown-menu {
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        .dropdown-item:hover {
            background-color: #f1f8e9;
        }

        /* Contenedor principal para la información adicional */
        .info-container {
            max-width: 900px;
            margin: 3rem auto 4rem auto;
            background-color: rgba(0, 0, 0, 0.55);
            border-radius: 15px;
            padding: 2rem 2.5rem;
            box-shadow: 0 0 15px rgba(0,0,0,0.5);
        }

        .info-container h2 {
            color: #a5d6a7;
            margin-bottom: 1rem;
            font-weight: 700;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.7);
        }

        .info-container p, .info-container ul {
            font-size: 1.1rem;
            line-height: 1.6;
            color: #e0e0e0;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
        }
        .info-container ul {
            list-style-type: disc;
            margin-left: 2rem;
        }

        footer {
            text-align: center;
            font-size: 0.9rem;
            margin-top: 2rem;
            color: #ccc;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container">
    <a class="navbar-brand" href="#"><i class="bi bi-hospital"></i> SANNA</a>
    <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto gap-2">
        <li class="nav-item">
          <a class="nav-link" href="SedesController"><i class="bi bi-calendar-check"></i> Reservar cita médica</a>
        </li>

        <!-- Mis citas con submenú -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="citasDropdown" role="button" data-bs-toggle="dropdown">
            <i class="bi bi-journal-medical"></i> Mis citas
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="citasDropdown">
            <li><a class="dropdown-item" href="CitaCancelarController"><i class="bi bi-calendar-event"></i> Citas próximas</a></li>
            <li><a class="dropdown-item" href="HistorialClinicoController"><i class="bi bi-file-earmark-medical"></i> Historial clínico</a></li>
          </ul>
        </li>

        <!-- Mi cuenta -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="cuentaDropdown" role="button" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle"></i> Mi cuenta
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="cuentaDropdown">
            <li><a class="dropdown-item" href="ActualizarPacienteController"><i class="bi bi-person"></i> Perfil</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="login.jsp"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Contenedor con la información solicitada -->
<div class="info-container">
    <h1 class="mb-4 text-center">Clínica SANNA</h1>

    <section class="mb-4">
        <h2>Visión</h2>
        <p>Ser el mejor sistema integrado de salud a nivel nacional, brindando acceso a los más altos estándares de calidad y seguridad médica.</p>
    </section>

    <section class="mb-4">
        <h2>Misión</h2>
        <p>Brindar tranquilidad a los pacientes y sus familias a través de servicios integrados de salud accesibles y de alta calidad, utilizando las mejores prácticas médicas con personal ético y altamente calificado.</p>
    </section>

    <section class="mb-4">
        <h2>Valores</h2>
        <ul>
            <li>Excelencia en el servicio y el cuidado de la salud</li>
            <li>Alta calidad médica y seguridad del paciente</li>
            <li>Integridad, respeto y compromiso</li>
            <li>Responsabilidad en el manejo de recursos</li>
            <li>Accesibilidad a productos y servicios</li>
        </ul>
    </section>

    <section class="mb-4">
        <h2>Historia y logros destacados</h2>
        <p>Fundada el 25 de abril de 1975, la Clínica SANNA ha sido pionera en la medicina peruana:</p>
        <ul>
            <li>En 1991, realizó los dos primeros trasplantes de corazón en la historia médica privada del país.</li>
            <li>En 1998, efectuó el primer implante coclear en el Perú, recuperando la audición de un paciente con sordera neurosensorial.</li>
            <li>Fue el primer establecimiento privado en contar con un centro de diálisis.</li>
            <li>En 2012, realizó el primer trasplante de médula ósea en la medicina privada peruana.</li>
            <li>Es la única clínica privada acreditada por el Ministerio de Salud para realizar trasplantes de médula ósea, tanto autólogos como alogénicos.</li>
            <li>Actualmente, la Clínica SANNA cuenta con más de 400 médicos especialistas y ofrece servicios de alta complejidad como trasplantes de médula ósea y tratamientos oncológicos.</li>
            <li>Ha implementado tecnología de última generación, como el software AWSERVER para procesamiento de imágenes y un ecógrafo de alta resolución 6D.</li>
            <li>La clínica también ha desarrollado una aplicación móvil que permite a los pacientes programar citas, acceder a su historial médico y realizar otras gestiones desde su celular, mejorando así la atención y experiencia del paciente.</li>
            <li>Con una infraestructura moderna y un enfoque en la innovación y la calidad, la Clínica SANNA continúa posicionándose como líder en el sector salud en el Perú.</li>
        </ul>
    </section>
</div>

<footer>
    &copy; 2025 Clínica SANNA - Todos los derechos reservados.
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

