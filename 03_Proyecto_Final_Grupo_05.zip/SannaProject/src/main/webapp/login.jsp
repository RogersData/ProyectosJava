<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Iniciar sesión - Paciente</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to right, #e6f4ea, #d0f0dc);
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', sans-serif;
    }

    .card {
      max-width: 420px;
      border: none;
      border-radius: 1.5rem;
      box-shadow: 0 8px 24px rgba(0, 128, 0, 0.15);
      animation: fadeIn 0.8s ease-in-out;
    }

    .card-title {
      color: #2f6f3e;
      font-weight: bold;
      font-size: 1.8rem;
    }

    .form-label {
      font-weight: 500;
      color: #2f6f3e;
    }

    .form-control:focus {
      border-color: #2f6f3e;
      box-shadow: 0 0 0 0.2rem rgba(47, 111, 62, 0.2);
    }

    .btn-primary {
      background-color: #2f6f3e;
      border: none;
    }

    .btn-primary:hover {
      background-color: #265e34;
    }

    .btn-secondary {
      background-color: #a5d6a7;
      color: #1b5e20;
      border: none;
    }

    .btn-secondary:hover {
      background-color: #81c784;
      color: #145a32;
    }

    .input-group-text {
      background-color: #e8f5e9;
      border: 1px solid #cce5d2;
      color: #2f6f3e;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-10px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>

  <div class="card p-4">
    <h3 class="card-title text-center mb-4">Iniciar Sesión</h3>

    <!-- Formulario de login -->
    <form action="/SannaProject/LoginController" method="post">
      <div class="mb-3">
        <label for="username" class="form-label">DNI</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-person-vcard"></i></span>
          <input name="txtdni" type="text" class="form-control" id="username" placeholder="Ingresa tu DNI" required>
        </div>
      </div>

      <div class="mb-3">
        <label for="password" class="form-label">Contraseña</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
          <input name="txtclave" type="password" class="form-control" id="password" placeholder="Ingresa tu contraseña" required>
        </div>
      </div>

      <div class="d-grid gap-2">
        <button type="submit" class="btn btn-primary" name="btn-login">Ingresar</button>
      </div>
    </form>

    <form action="/SannaProject/registrarPaciente.jsp" method="post" class="mt-3">
      <div class="d-grid">
        <button type="submit" class="btn btn-secondary">Registrarse</button>
      </div>
    </form>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>