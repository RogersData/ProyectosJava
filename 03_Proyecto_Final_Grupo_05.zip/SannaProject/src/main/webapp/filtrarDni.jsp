<%-- 
    Document   : filtrarDni
    Created on : 10 jul. 2025, 20:15:21
    Author     : Mel
--%>

<%@ page import="java.util.List" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Buscar Citas por DNI</title>

    <!-- Bootstrap y Font Awesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h3 class="text-center text-primary">Buscar Citas Médicas</h3>

    <!-- Formulario de búsqueda -->
    <form action="filtradoPorDni" method="get" class="mt-4">
        <div class="input-group input-group-lg">
            <input type="text" name="dni" class="form-control" placeholder="Ingrese su DNI" required>
            <div class="input-group-append">
                <button class="btn btn-primary" type="submit">
                    <i class="fas fa-search"></i> Buscar
                </button>
            </div>
        </div>
    </form>

    <%
        List<String> citas = (List<String>) request.getAttribute("citas");
        String dni = (String) request.getAttribute("dni");

        if (dni != null) {
    %>
        <hr/>
        <h4 class="text-success mt-4">Citas encontradas para DNI: <%= dni %></h4>

        <%
            if (citas != null && !citas.isEmpty()) {
        %>
            <ul class="list-group mt-3">
                <% for (String cita : citas) { %>
                    <li class="list-group-item"><%= cita %></li>
                <% } %>
            </ul>
        <%
            } else {
        %>
            <div class="alert alert-warning mt-3">No se encontraron citas para ese DNI.</div>
        <%
            }
        }
    %>

</div>

</body>
</html>