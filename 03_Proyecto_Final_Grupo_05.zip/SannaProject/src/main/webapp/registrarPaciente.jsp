<%-- 
    Document   : registrarPaciente
    Created on : 30 may. 2025, 1:26:22 p. m.
    Author     : USUARIO
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
         <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
        <title>Registro de Paciente</title>
        <style>
    body {
      background-color: #e9f7ef; /* Verde muy claro */
    }

    .form-container {
      background-color: #ffffff;
      border-radius: 15px;
      padding: 30px;
      box-shadow: 0 4px 12px rgba(0, 128, 0, 0.1);
    }

    h2 {
      color: #2e7d32; /* Verde oscuro */
    }

    .btn-green {
      background-color: #4caf50;
      border-color: #4caf50;
      color: white;
    }

    .btn-green:hover {
      background-color: #388e3c;
      border-color: #388e3c;
    }

    label {
      color: #2e7d32;
    }

    .form-control:focus {
      border-color: #66bb6a;
      box-shadow: 0 0 0 0.2rem rgba(76, 175, 80, 0.25);
    }
  </style>
    </head>
<body>
  <div class="container mt-5">
    <div class="form-container">
      <h2 class="mb-4">Registro de Paciente</h2>
      <form action="/SannaProject/RegistroPacienteController" method="post">
        <div class="row mb-3">
          <div class="col-md-6">
            <label for="nombre" class="form-label">Nombre</label>
            <input name="txtNombrePaciente" type="text" class="form-control" id="nombre" placeholder="Ingrese su nombre">
          </div>
          <div class="col-md-6">
            <label for="apellido" class="form-label">Apellido</label>
            <input name="txtApelidoPaciente" type="text" class="form-control" id="apellido" placeholder="Ingrese su apellido">
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="dni" class="form-label">DNI</label>
            <input name="txtdniPaciente" type="text" class="form-control" id="dni" placeholder="Ingrese su número de DNI">
          </div>
          <div class="col-md-6">
            <label for="clave" class="form-label">Clave / Contraseña</label>
            <input name="txtContrasenaPaciente" type="password" class="form-control" id="clave" placeholder="Ingrese una clave segura">
          </div>
        </div>

        <div class="mb-3">
          <label for="fechaNacimiento" class="form-label">Fecha de Nacimiento</label>
          <input name="txtfechaNacimiento" type="date" class="form-control" id="fechaNacimiento">
        </div>

        <div class="mb-3">
          <label class="form-label">Sexo</label>
          <div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="sexo" value="M" id="masculino" value="masculino">
              <label class="form-check-label" for="masculino">Masculino</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="sexo" value="F" id="femenino" value="femenino">
              <label class="form-check-label" for="femenino">Femenino</label>
            </div>
          </div>
        </div>

        <div class="mb-3">
          <label for="direccion" class="form-label">Dirección</label>
          <input name="txtdireccion" type="text" class="form-control" id="direccion" placeholder="Ingrese su dirección">
        </div>

        <div class="mb-3">
          <label for="telefono" class="form-label">Teléfono</label>
          <input name="txttelefono" type="tel" class="form-control" id="telefono" placeholder="Ingrese su número de teléfono">
        </div>

        <div class="mb-3">
          <label for="email" class="form-label">Correo Electrónico</label>
          <input name="txtcorreoPaciente" type="email" class="form-control" id="email" placeholder="ejemplo@correo.com">
        </div>

        <button type="submit" class="btn btn-green" name="btn-registroPacienteGuardar" >Registrar</button>
        <button type="submit" class="btn btn-secondary" name="btn-volver">Volver</button>
        
         </form>
    
      

      
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  
  
  <!-- Modal de éxito -->
<div class="modal fade" id="modalExito" tabindex="-1" aria-labelledby="modalExitoLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title" id="modalExitoLabel">Registro Exitoso</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        El paciente fue registrado correctamente.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-bs-dismiss="modal">Aceptar</button>
      </div>
    </div>
  </div>
</div>
<%
Boolean citaCancelada = (Boolean) session.getAttribute("citaCancelada");
if (citaCancelada != null && citaCancelada) {
    session.removeAttribute("citaCancelada"); // Elimina para que no se muestre de nuevo
%>
<script>
    window.onload = function () {
      var myModalEl = document.getElementById('modalExito');
      var myModal = new bootstrap.Modal(myModalEl);
      myModal.show();
    };
</script>
<%
}
%>
</body>

</html>
