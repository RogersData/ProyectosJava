<%-- 
    Document   : actualizarPaciente
    Created on : 29 may. 2025, 6:17:07 p. m.
    Author     : USUARIO
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%@ page import="Dao.ActualizarPacienteDao" %>
<%@ page import="Model.PacienteModel" %>
<%@ page import="Model.PacienteModel" %>
<%
    PacienteModel paciente = (PacienteModel) request.getAttribute("paciente");
 
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Actualizar Paciente</title>
     <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        .navbar-custom {
            background: linear-gradient(135deg, #4caf50, #2e7d32);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .nav-link {
            color: #fff !important;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .nav-link:hover {
            color: #dcedc8 !important;
        }

        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: #ffffff !important;
        }

        .dropdown-menu {
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }

        .dropdown-item:hover {
            background-color: #f1f8e9;
        }
    </style>
<body>

<!-- AQUI IRÍA TU NAVBAR, SI DESEAS -->
<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container">
    <a class="navbar-brand" href="#"><i class="bi bi-hospital"></i> SANNA</a>
    <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto gap-2">
          <ul class="navbar-nav ms-auto gap-2">
          <li class="nav-item">
          <a class="nav-link" href="menuPaciente.jsp"><i class="bi bi-calendar-check"></i> Quienes Somos</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="SedesController"><i class="bi bi-calendar-check"></i> Reservar cita médica</a>
        </li>

        <!-- Mis citas con submenú -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="citasDropdown" role="button" data-bs-toggle="dropdown">
            <i class="bi bi-journal-medical"></i> Mis citas
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="citasDropdown">
            <li><a class="dropdown-item" href="CitaCancelarController"><i class="bi bi-calendar-event"></i> Citas próximas</a></li>
            <li><a class="dropdown-item" href="HistorialClinicoController"><i class="bi bi-file-earmark-medical"></i> Historial clínico</a></li>
          </ul>
        </li>

        <!-- Mi cuenta -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="cuentaDropdown" role="button" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle"></i> Mi cuenta
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="cuentaDropdown">
            <li><a class="dropdown-item" href="ActualizarPacienteController"><i class="bi bi-person"></i> Perfil</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="login.jsp"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-5 mb-5">
    <h2 class="mb-4">Actualizar Datos Personales</h2>
    <%
    String mensaje = (String) request.getAttribute("mensaje");
    String tipoMensaje = (String) request.getAttribute("tipoMensaje"); // "success" o "danger"
    if (mensaje != null && tipoMensaje != null) {
%>
    <div class="alert alert-<%= tipoMensaje %> alert-dismissible fade show" role="alert">
        <%= mensaje %>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<%
    }
%>
    <form action="ActualizaPcienteV2Controller" method="post">
        <input type="hidden" name="accion" value="actualizar">
       <input type="hidden" name="id_paciente" value="<%= paciente != null ? paciente.getId_paciente() : "" %>">
        <div class="row mb-3">
            <div class="col-md-6">
                <label for="nombres" class="form-label">Nombres</label>
                <input type="text" class="form-control" id="nombres" name="nombres" value="<%= paciente != null ? paciente.getNombres() : "" %>" required>
            </div>
            <div class="col-md-6">
                <label for="apellidos" class="form-label">Apellidos</label>
                <input type="text" class="form-control" id="apellidos" name="apellidos" value="<%= paciente != null ? paciente.getApellidos() : "" %>" required>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-4">
                <label for="fecha_nacimiento" class="form-label">Fecha de Nacimiento</label>
                <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" value="<%= paciente != null ? paciente.getFecha_nacimiento() : "" %>" required>
            </div>
            <div class="col-md-4">
                <label for="sexo" class="form-label">Sexo</label>
                <select class="form-select" id="sexo" name="sexo" required>
                    <option value="">Seleccione</option>
                    <option value="M" <%= (paciente != null && "M".equals(paciente.getSexo())) ? "selected" : "" %>>Masculino</option>
                    <option value="F" <%= (paciente != null && "F".equals(paciente.getSexo())) ? "selected" : "" %>>Femenino</option>
                    <option value="Otro" <%= (paciente != null && "Otro".equals(paciente.getSexo())) ? "selected" : "" %>>Otro</option>
                </select>
            </div>
            <div class="col-md-4">
                <label for="telefono" class="form-label">Teléfono</label>
                <input type="text" class="form-control" id="telefono" name="telefono" value="<%= paciente != null ? paciente.getTelefono() : "" %>" required>
            </div>
        </div>

        <div class="mb-3">
            <label for="direccion" class="form-label">Dirección</label>
            <input type="text" class="form-control" id="direccion" name="direccion" value="<%= paciente != null ? paciente.getDireccion() : "" %>" required>
        </div>

        <div class="mb-4">
            <label for="email" class="form-label">Correo Electrónico</label>
            <input type="email" class="form-control" id="email" name="email" value="<%= paciente != null ? paciente.getEmail() : "" %>" required>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" name="boton" value="actualizar" class="btn btn-warning"><i class="bi bi-pencil-square"></i> Actualizar</button>
            
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

