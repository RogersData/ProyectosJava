<%-- 
    Document   : reservarCitaPaciente
    Created on : 4 jun. 2025, 4:13:49 p. m.
    Author     : USUARIO
--%>

<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>Reservar Cita</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar-custom {
            background: linear-gradient(135deg, #4caf50, #2e7d32);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .nav-link {
            color: #fff !important;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .nav-link:hover {
            color: #dcedc8 !important;
        }

        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: #ffffff !important;
        }

        .dropdown-menu {
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }

        .dropdown-item:hover {
            background-color: #f1f8e9;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container">
    <a class="navbar-brand" href="#"><i class="bi bi-hospital"></i> SANNA</a>
    <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto gap-2">
          <li class="nav-item">
          <a class="nav-link" href="menuPaciente.jsp"><i class="bi bi-calendar-check"></i> Quienes Somos</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="#"><i class="bi bi-calendar-check"></i> Reservar cita médica</a>
        </li>
         <!-- Mis citas con submenú -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="citasDropdown" role="button" data-bs-toggle="dropdown">
            <i class="bi bi-journal-medical"></i> Mis citas
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="citasDropdown">
           <li><a class="dropdown-item" href="CitaCancelarController"><i class="bi bi-calendar-event"></i> Citas próximas</a></li>
            <li><a class="dropdown-item" href="HistorialClinicoController"><i class="bi bi-file-earmark-medical"></i> Historial clínico</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="cuentaDropdown" role="button" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle"></i> Mi cuenta
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="cuentaDropdown">
            <li><a class="dropdown-item" href="ActualizarPacienteController"><i class="bi bi-person"></i> Perfil</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" href="login.jsp"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Formulario de reserva de cita -->
<main class="container mt-5">
  <h2 class="mb-4">Reservar cita médica</h2>

  
  
  <!-- Sede -->
    <div class="col-md-6">
  <label for="sede" class="form-label">Sede</label>
  <select class="form-select" id="sede" name="sede" required>
    <option value="">Seleccione una sede</option>
    <c:forEach var="sede" items="${sedes}">
      <option value="${sede.getSede_id()}">${sede.getNombre()}</option>
    </c:forEach>
  </select>
</div>
  
  
    <!-- Combo de Especialidad -->
<div class="col-md-6">
  <label for="especialidad" class="form-label">Especialidad</label>
  <select class="form-select" id="especialidad" name="especialidad" required>
    <option value="">Seleccione una especialidad</option>
  </select>
</div>
  
 

 <!-- Combo de Doctores (se llenará con JS) -->
<div class="col-md-6">
  <label for="doctor" class="form-label">Doctor</label>
  <select class="form-select" id="doctor" name="doctor" required>
    <option value="">Seleccione un doctor</option>
  </select>
</div>


    <!-- Motivo de la consulta -->
   <div class="col-12">
  <label for="motivoConsulta" class="form-label">Motivo de la consulta</label>
  <textarea class="form-control" id="motivoConsulta" name="motivo" rows="3" placeholder="Describe brevemente el motivo de tu consulta" required></textarea>
</div>

    <!-- Botón -->
<form id="buscarCitasForm">
  <div class="row g-3">

    <!-- Aquí van tus campos actuales de sede, especialidad, doctor y motivo -->
    <!-- ... (ya lo tienes implementado) -->

    <!-- Botón -->
    <div class="col-12">
      <button type="submit" class="btn btn-success">Buscar</button>
    </div>
  </div>
</form>

<!-- Contenedor para las citas disponibles -->
<div id="citasDisponibles" class="mt-5"></div>
  
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
<script>
  $(document).ready(function () {
    $('#sede').on('change', function () {
      const sedeId = $(this).val();

      if (sedeId !== "") {
        $.ajax({
          url: 'EspecialidadController',
          type: 'GET',
          data: { sedeId: sedeId },
          dataType: 'json',
          success: function (data) {
            const especialidadSelect = $('#especialidad');
            especialidadSelect.empty();
            especialidadSelect.append('<option value="">Seleccione una especialidad</option>');

            $.each(data, function (index, especialidad) {
              especialidadSelect.append(
                $('<option>', {
                  value: especialidad.id_especialidad,
                  text: especialidad.nombre_especialidad
                })
              );
            });
          },
          error: function () {
            alert('Error al cargar especialidades. Intenta nuevamente.');
          }
        });
      } else {
        $('#especialidad').empty().append('<option value="">Seleccione una especialidad</option>');
      }
    });
  });
</script>
<script>
  $(document).ready(function () {
   

    $('#especialidad').on('change', function () {
      const sedeId = $('#sede').val();
      const especialidadId = $(this).val();

      if (sedeId !== "" && especialidadId !== "") {
        $.ajax({
          url: 'DoctoresController',
          type: 'GET',
          data: {
            sedeId: sedeId,
            especialidadId: especialidadId
          },
          dataType: 'json',
          success: function (data) {
            const doctorSelect = $('#doctor');
            doctorSelect.empty();
            doctorSelect.append('<option value="">Seleccione un doctor</option>');

            $.each(data, function (index, doctor) {
              doctorSelect.append(
                $('<option>', {
                  value: doctor.id_medico,
                  text: doctor.nombres + ' ' + doctor.apellidos
                })
              );
            });
          },
          error: function () {
            alert('Error al cargar doctores. Intenta nuevamente.');
          }
        });
      } else {
        $('#doctor').empty().append('<option value="">Seleccione un doctor</option>');
      }
    });
  });
</script>
<script>
  $(document).ready(function () {
    // Evento submit para buscar citas
    $('#buscarCitasForm').on('submit', function (e) {
      console.log('Submit detectado');
      e.preventDefault();

      const sedeId = $('#sede').val();
      const especialidadId = $('#especialidad').val();
      const doctorId = $('#doctor').val();

      if (!sedeId || !especialidadId || !doctorId) {
        alert('Por favor, selecciona todos los campos.');
        return;
      }

      $.ajax({
        url: 'BuscarCitaDisponibleController',
        type: 'GET',
        data: {
          sedeId: sedeId,
          especialidadId: especialidadId,
          doctorId: doctorId
        },
        dataType: 'json',
        success: function(data) {
          console.log("Respuesta completa:", data);
          const container = $('#citasDisponibles');
          container.empty();

          if (data.length === 0) {
            container.html('<div class="alert alert-warning">No hay citas disponibles.</div>');
            return;
          }

          let html = '<h4 class="mb-3">Citas disponibles</h4><div class="row g-3">';

          data.forEach(function (cita) {
            const plain = JSON.parse(JSON.stringify(cita));

            html +=
              '<div class="col-md-4">' +
                '<div class="card border-primary shadow-sm rounded-4">' +
                  '<div class="card-body text-center">' +
                    '<h5 class="card-title text-primary mb-3">Cita Disponible</h5>' +
                    '<p class="card-text"><i class="bi bi-calendar-event-fill"></i> <strong>Fecha:</strong> ' + plain.fecha + '</p>' +
                    '<p class="card-text"><i class="bi bi-clock-fill"></i> <strong>Hora:</strong> ' + plain.hora + '</p>' +
                    '<p class="card-text"><i class="bi bi-geo-alt-fill"></i> <strong>Sede:</strong> ' + plain.sede + '</p>' +
                    '<form method="POST" action="RegistrarCitaController" class="form-reserva">' +
                      '<input type="hidden" name="idDisponibilidad" value="' + plain.idDisponibilidad + '">' +
                      '<input type="hidden" name="fechaCita" value="' + plain.fecha + ' ' + plain.hora + '">' +
                      '<input type="hidden" name="motivo" class="motivoHidden">' + // campo hidden motivo
                      '<button type="submit" class="btn btn-success btn-sm mt-2">Reservar</button>' +
                    '</form>' +
                  '</div>' +
                '</div>' +
              '</div>';
          });

          html += '</div>';
          container.html(html);
        },
        error: function () {
          alert('Error al buscar citas disponibles. Intenta nuevamente.');
        }
      });
    });

    // Evento submit para el form de reserva, capturando motivo
    $(document).on('submit', '.form-reserva', function(e) {
      const motivoTexto = $('#motivoConsulta').val().trim();

      if (!motivoTexto) {
        e.preventDefault();
        alert('Por favor, escribe el motivo de la consulta.');
        return false;
      }

      // Poner motivo en el input hidden del form que se está enviando
      $(this).find('.motivoHidden').val(motivoTexto);
    });
  });
</script>

    
    <!-- Modal de éxito -->
<div class="modal fade" id="modalExito" tabindex="-1" aria-labelledby="modalExitoLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title" id="modalExitoLabel">¡Cita reservada exitosamente!</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        La cita fue registrada correctamente.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-bs-dismiss="modal">Aceptar</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal de error -->
<div class="modal fade" id="modalError" tabindex="-1" aria-labelledby="modalErrorLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title" id="modalErrorLabel">Error</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        Ocurrió un error al registrar la cita.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Aceptar</button>
      </div>
    </div>
  </div>
</div>


</body>

    <%
    String mensaje = request.getParameter("mensaje");
%>
<script>
    window.onload = function () {
        <% if ("exito".equals(mensaje)) { %>
            var modalExito = new bootstrap.Modal(document.getElementById('modalExito'));
            modalExito.show();

            document.getElementById('modalExito').addEventListener('hidden.bs.modal', function () {
                // Redirige a SedesController al cerrar modal
                window.location.href = 'SedesController';
            });
        <% } else if ("error".equals(mensaje)) { %>
            var modalError = new bootstrap.Modal(document.getElementById('modalError'));
            modalError.show();

            document.getElementById('modalError').addEventListener('hidden.bs.modal', function () {
                // Opcional: también redirige a SedesController o a donde quieras
                window.location.href = 'SedesController';
            });
        <% } %>
    };
</script>


<script>
  // Si la cita fue registrada con éxito, volvemos a ejecutar la búsqueda de citas automáticamente
  $(document).ready(function () {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('mensaje') === 'exito') {
      const sedeId = $('#sede').val();
      const especialidadId = $('#especialidad').val();
      const doctorId = $('#doctor').val();

      // Volvemos a buscar citas disponibles si los campos siguen seleccionados
      if (sedeId && especialidadId && doctorId) {
        $('#buscarCitasForm').submit();
      }
    }
  });
</script>


<script>
  $(document).ready(function () {
    setTimeout(function () {
      $(".alert").alert('close');
    }, 4000); // 4 segundos
  });
</script>
</html>

