<%-- 
    Document   : menuMedico
    Created on : 8 jul. 2025, 10:53:35 p. m.
    Author     : Diego
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="javax.servlet.http.HttpSession"%>
<%
    HttpSession sesion = request.getSession(false);
    String dniMedico = (String) sesion.getAttribute("dniMedico");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Menú Médico - Clínica SANNA</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body, html {
            height: 100%;
            margin: 0;
        }

        .background-container {
            background-color: #f5fff7;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            position: relative;
        }

        .background-image {
            background-image: url('https://play-lh.googleusercontent.com/bQHkZciMrMyU0Pwyka5gqfaOHZnOS4BoeP47s0T6rG-TKYL469BRbMMGjmiS0HAEMDA=w240-h480-rw');
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center;
            width: 280px;
            height: 280px;
        }

        .navbar-custom {
            background: linear-gradient(135deg, #66bb6a, #388e3c);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            width: 100%;
            position: absolute;
            top: 0;
        }

        .nav-link {
            color: #fff !important;
            font-weight: 500;
        }

        .nav-link:hover {
            color: #c8e6c9 !important;
        }

        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: #ffffff !important;
        }

        .dropdown-menu {
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }

        .dropdown-item:hover {
            background-color: #f1f8e9;
        }

        .medico-name {
            background-color: rgba(0, 0, 0, 0.6);
            color: #ffffff;
            text-align: center;
            padding: 1rem 0;
            font-weight: 500;
            font-size: 1.1rem;
            width: 100%;
            position: absolute;
            bottom: 0;
        }
    </style>
</head>
<body>
<div class="background-container">

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="bi bi-heart-pulse"></i> SANNA</a>
            <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto gap-2">

                    <!-- Ver citas -->
                    <li class="nav-item">
                        <a class="nav-link" href="VerCitasMedicoController"><i class="bi bi-calendar-check"></i> Ver mis citas</a>
                    </li>

                    <!-- Mi cuenta -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="cuentaDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> Mi cuenta
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="cuentaDropdown">
                            <li><a class="dropdown-item" href="PerfilMedicoController"><i class="bi bi-person-gear"></i> Perfil</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="loginMedico.jsp"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a></li>
                        </ul>
                    </li>

                </ul>
            </div>
        </div>
    </nav>

    <!-- Imagen -->
    <div class="background-image"></div>

    <!-- Nombre del médico -->
    <div class="medico-name">
        Médico (DNI): <strong><%= dniMedico != null ? dniMedico : "No identificado" %></strong>
    </div>
    
    <%
    String mensaje = (String) session.getAttribute("mensaje");
    if (mensaje != null) {
%>
    <div class="container mt-4">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <%= mensaje %>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
<%
        session.removeAttribute("mensaje"); // Elimina el mensaje para no repetirlo al recargar
    }
%>


</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

