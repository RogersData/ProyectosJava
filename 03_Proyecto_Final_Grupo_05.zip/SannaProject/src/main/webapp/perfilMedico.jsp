<%-- 
    Document   : perfilMedico
    Created on : 10 jul. 2025, 19:34:47
    Author     : Mel
--%>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Perfil del Médico</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px; }
        .contenedor { background-color: white; padding: 20px; border-radius: 8px; width: 500px; margin: auto; box-shadow: 0px 0px 10px #ccc; }
        h2 { text-align: center; color: #333; }
        label { font-weight: bold; }
        input[type="text"], input[type="email"] {
            width: 100%; padding: 8px; margin-bottom: 10px; border-radius: 5px; border: 1px solid #ccc;
        }
        button {
            width: 100%; padding: 10px; background-color: #3498db; color: white; border: none; border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="contenedor">
        <h2>Perfil del Médico</h2>

        <%
            String datos = (String) request.getAttribute("infoMedico");

            if (datos != null && datos.contains("ID Médico")) {
                // Separar el string por coma
                String[] partes = datos.split(",");

                String idMedico = partes[0].split(":")[1].trim();
                String nombres = partes[1].split(":")[1].trim();
                String apellidos = partes[2].split(":")[1].trim();
                String telefono = partes[3].split(":")[1].trim();
                String email = partes[4].split(":")[1].trim();
                String especialidad = partes[5].split(":")[1].trim();
        %>

        <form action="ActualizarMedicoController" method="post">
            <input type="hidden" name="idMedico" value="<%= idMedico %>">

            <label>ID Médico:</label>
            <input type="text" value="<%= idMedico %>" disabled>

            <label>Nombres:</label>
            <input type="text" value="<%= nombres %>" disabled>

            <label>Apellidos:</label>
            <input type="text" value="<%= apellidos %>" disabled>

            <label>Especialidad:</label>
            <input type="text" value="<%= especialidad %>" disabled>

            <label>Teléfono:</label>
            <input type="text" name="telefono" value="<%= telefono %>" required>

            <label>Email:</label>
            <input type="email" name="email" value="<%= email %>" required>

            
        </form>

        <%
            } else {
        %>
            <p>No se encontraron datos del médico.</p>
        <%
            }
        %>
    </div>
</body>
</html>


