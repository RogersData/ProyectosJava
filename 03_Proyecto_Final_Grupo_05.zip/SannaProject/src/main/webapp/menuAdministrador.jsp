<%-- 
    Document   : menuAdministrador
    Created on : 26 jun. 2025, 5:51:04 p. m.
    Author     : USUARIO
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Menu Administrador - Clínica SANNA</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body, html {
            height: 100%;
            margin: 0;
        }

        .background-container {
            background-color: #f0f0f0; /* color de fondo neutro */
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            position: relative;
        }

        .background-image {
            background-image: url('https://play-lh.googleusercontent.com/bQHkZciMrMyU0Pwyka5gqfaOHZnOS4BoeP47s0T6rG-TKYL469BRbMMGjmiS0HAEMDA=w240-h480-rw');
            background-size: contain;
            background-repeat: no-repeat;
            background-position: center;
            width: 300px; /* tamaño mediano, ajusta si deseas */
            height: 300px;
        }

        .navbar-custom {
            background: linear-gradient(135deg, #4caf50, #2e7d32);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            width: 100%;
            position: absolute;
            top: 0;
        }

        .nav-link {
            color: #fff !important;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .nav-link:hover {
            color: #dcedc8 !important;
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: #ffffff !important;
        }
        .dropdown-menu {
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        .dropdown-item:hover {
            background-color: #f1f8e9;
        }

        /* Estilo para el nombre del administrador al pie */
        .admin-name {
            background-color: rgba(0, 0, 0, 0.6);
            color: #ffffff;
            text-align: center;
            padding: 1rem 0;
            font-weight: 500;
            font-size: 1.1rem;
            width: 100%;
            position: absolute;
            bottom: 0;
        }
    </style>
</head>
<body>
<div class="background-container">

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="bi bi-hospital"></i> SANNA</a>
            <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto gap-2">

                    <!-- Actualización de datos -->
                    <li class="nav-item">
                        <a class="nav-link" href="filtradoPorDni"><i class="bi bi-pencil-square"></i> Historial Clínico</a>
                    </li>


                    <!-- Doctor y Paciente -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="doctorPacienteDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-people"></i> Doctor y Paciente
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="doctorPacienteDropdown">
                            <li><a class="dropdown-item" href="buscarActualizarMedico.jsp"><i class="bi bi-person-badge"></i> Gestionar doctores</a></li>
                            <li><a class="dropdown-item" href="administradorActualizarPaciente.jsp"><i class="bi bi-person"></i> Gestionar pacientes</a></li>
                        </ul>
                    </li>

                    <!-- Mi cuenta -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="cuentaDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> Mi cuenta
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="cuentaDropdown">
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="loginAdministrador.jsp"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a></li>
                        </ul>
                    </li>

                </ul>
            </div>
        </div>
    </nav>

    <!-- Imagen centrada -->
    <div class="background-image"></div>

    <!-- Nombre del Administrador -->
    <div class="admin-name">
        Administrador: <strong>Juan Pérez</strong> <!-- reemplaza con variable JSP si usas sesión -->
    </div>
    <%
    String mensaje = (String) session.getAttribute("mensaje");
    if (mensaje != null) {
%>
    <div class="alert alert-success text-center mt-4">
        <%= mensaje %>
    </div>
<%
    session.removeAttribute("mensaje"); // eliminar después de mostrar
    }
%>


</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
