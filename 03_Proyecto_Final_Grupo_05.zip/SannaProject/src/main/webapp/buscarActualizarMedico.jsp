<%-- 
    Document   : buscarActualizarMedico
    Created on : 10 jul. 2025, 21:18:55
    Author     : Mel
--%>

<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Buscar y Actualizar Médico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow p-4">
        <h3 class="text-center text-success">Buscar Médico por DNI</h3>

        <!-- Formulario de búsqueda -->
        <form action="BuscarMedicoController" method="post" class="row g-3 mt-4">
            <div class="col-md-10">
                <input type="text" name="dni" class="form-control" placeholder="Ingrese DNI" required>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Buscar</button>
            </div>
        </form>

        <!-- Mostrar resultado -->
        <%
            String resultado = (String) request.getAttribute("resultado");
            if (resultado != null) {
        %>
            <div class="alert alert-info mt-4 text-center">
                <%= resultado %>
            </div>

            <%
                // Si contiene "ID Médico", extraemos los datos para mostrar en el formulario de actualización
                if (resultado.contains("ID Médico")) {
                    String[] partes = resultado.split(",");
                    String idMedico = partes[0].split(":")[1].trim();
                    String nombres = partes[1].split(":")[1].trim();
                    String apellidos = partes[2].split(":")[1].trim();
                    String telefono = partes[3].split(":")[1].trim();
                    String email = partes[4].split(":")[1].trim();
                    String especialidad = partes[5].split(":")[1].trim();
            %>

            <!-- Formulario de actualización -->
            <hr>
            <h5 class="text-center text-primary">Actualizar Contacto del Médico</h5>
            <form action="ActualizarContactoController" method="post" class="row g-3 mt-3">
                <input type="hidden" name="idMedico" value="<%= idMedico %>">

                <div class="col-md-6">
                    <label>Nombres:</label>
                    <input type="text" class="form-control" value="<%= nombres %>" disabled>
                </div>
                <div class="col-md-6">
                    <label>Apellidos:</label>
                    <input type="text" class="form-control" value="<%= apellidos %>" disabled>
                </div>
                <div class="col-md-6">
                    <label>Especialidad:</label>
                    <input type="text" class="form-control" value="<%= especialidad %>" disabled>
                </div>
                <div class="col-md-6">
                    <label>Teléfono:</label>
                    <input type="text" name="telefono" class="form-control" value="<%= telefono %>" required>
                </div>
                <div class="col-md-12">
                    <label>Email:</label>
                    <input type="email" name="email" class="form-control" value="<%= email %>" required>
                </div>
                <div class="col-md-12 text-end">
                    <button type="submit" class="btn btn-warning">Actualizar Contacto</button>
                </div>
            </form>

            <% } // fin if contiene ID Médico %>
        <% } // fin if resultado != null %>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
