<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="Model.PacienteModel" %>
<%
    // Simula obtener el paciente desde request, enviado por tu servlet BuscarPacienteController
    PacienteModel paciente = (PacienteModel) request.getAttribute("pacienteEncontrado");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Actualizar Paciente - Clínica SANNA</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body, html {
            height: 100%;
            margin: 0;
            background-color: #e8f5e9;
        }

        .navbar-custom {
            background: linear-gradient(135deg, #4caf50, #2e7d32);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .form-card {
            max-width: 650px;
            margin: 100px auto 40px auto;
            background: #ffffff;
            border-radius: 15px;
            padding: 2rem 2.5rem;
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }

        .form-card h4 {
            margin-bottom: 1.5rem;
            color: #2e7d32;
            font-weight: bold;
            text-align: center;
        }

        .input-group-text {
            background-color: #4caf50;
            color: white;
            border: none;
        }

        .btn-success, .btn-primary {
            font-weight: 600;
        }

        .admin-name {
            background-color: rgba(0, 0, 0, 0.6);
            color: #ffffff;
            text-align: center;
            padding: 1rem 0;
            font-weight: 500;
            font-size: 1.1rem;
            width: 100%;
            position: fixed;
            bottom: 0;
        }

        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: #ffffff !important;
        }
        .nav-link {
            color: #fff !important;
            font-weight: 500;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#"><i class="bi bi-hospital"></i> SANNA</a>
        <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto gap-2">
                <li class="nav-item">
                    <a class="nav-link" href="ActualizarDatosController"><i class="bi bi-pencil-square"></i> Historial Clínico</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="doctorPacienteDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-people"></i> Doctor y Paciente
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="doctorPacienteDropdown">
                        <li><a class="dropdown-item" href="GestionDoctorController"><i class="bi bi-person-badge"></i> Gestionar doctores</a></li>
                        <li><a class="dropdown-item" href="administradorActualizarPaciente.jsp"><i class="bi bi-person"></i> Gestionar pacientes</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="cuentaDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i> Mi cuenta
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="cuentaDropdown">
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="login.jsp"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Formulario -->
<div class="form-card">
    <h4>Buscar Paciente</h4>

    <!-- Buscar DNI -->
    <form action="AdministradorPacienteActualizarController" method="get" class="mb-4">
        <div class="input-group">
            <span class="input-group-text"><i class="bi bi-credit-card"></i></span>
            <input type="text" name="dni" class="form-control" placeholder="Ingrese DNI del paciente" required>
            <button class="btn btn-success" type="submit"><i class="bi bi-search"></i> Buscar</button>
        </div>
    </form>
    
<% String mensajeError = (String) request.getAttribute("mensajeError"); %>
<% if (mensajeError != null) { %>
<div class="alert alert-danger" id="mensajeError"><%= mensajeError %></div>
<% } %>


<% String mensajeExito = (String) request.getAttribute("mensajeExito"); %>
<% if (mensajeExito != null) { %>
<div class="alert alert-success" id="mensajeExito"><%= mensajeExito %></div>
<% } %>



    <% if (paciente != null) { %>
    <!-- Datos del Paciente si existe -->
    <h4>Actualizar Datos</h4>
    <form action="AdministradorPacienteActualizarController" method="post">
        <!-- Campo oculto DNI -->
        <input type="hidden" name="dni" value="<%= paciente.getDniPaciente()%>">

        <div class="mb-3 input-group">
            <span class="input-group-text"><i class="bi bi-person"></i></span>
            <input type="text" class="form-control" name="nombres" value="<%= paciente.getNombres() %>" placeholder="Nombres" required>
        </div>
        <div class="mb-3 input-group">
            <span class="input-group-text"><i class="bi bi-person-lines-fill"></i></span>
            <input type="text" class="form-control" name="apellidos" value="<%= paciente.getApellidos() %>" placeholder="Apellidos" required>
        </div>
        <div class="mb-3 input-group">
            <span class="input-group-text"><i class="bi bi-calendar-event"></i></span>
            <input type="date" class="form-control" name="fechaNacimiento" value="<%= paciente.getFecha_nacimiento()!= null ? paciente.getFecha_nacimiento().toString() : "" %>" required>
        </div>
        <div class="mb-3 input-group">
            <span class="input-group-text"><i class="bi bi-gender-ambiguous"></i></span>
            <select class="form-select" name="sexo" required>
                <option value="">Sexo</option>
                <option value="M" <%= paciente.getSexo().equals("M") ? "selected" : "" %>>Masculino</option>
                <option value="F" <%= paciente.getSexo().equals("F") ? "selected" : "" %>>Femenino</option>
            </select>
        </div>
        <div class="mb-3 input-group">
            <span class="input-group-text"><i class="bi bi-telephone"></i></span>
            <input type="text" class="form-control" name="telefono" value="<%= paciente.getTelefono() %>" placeholder="Teléfono" required>
        </div>
        <div class="mb-3 input-group">
            <span class="input-group-text"><i class="bi bi-house-door"></i></span>
            <input type="text" class="form-control" name="direccion" value="<%= paciente.getDireccion() %>" placeholder="Dirección" required>
        </div>
        <div class="mb-3 input-group">
            <span class="input-group-text"><i class="bi bi-envelope"></i></span>
            <input type="email" class="form-control" name="correo" value="<%= paciente.getEmail()%>" placeholder="Correo Electrónico" required>
        </div>
        <button type="submit" class="btn btn-primary w-100"><i class="bi bi-pencil-square"></i> Actualizar</button>
    </form>
    <% } %>
</div>

<!-- Footer -->
<div class="admin-name">
    Administrador: <strong>Juan Pérez</strong>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Espera a que el DOM esté cargado
    document.addEventListener("DOMContentLoaded", function() {
        // Ocultar mensaje de error después de 10 segundos
        const mensajeError = document.getElementById("mensajeError");
        if (mensajeError) {
            setTimeout(() => {
                mensajeError.style.display = "none";
            }, 5000); // 10000 ms = 10 segundos
        }

        // Ocultar mensaje de éxito después de 10 segundos
        const mensajeExito = document.getElementById("mensajeExito");
        if (mensajeExito) {
            setTimeout(() => {
                mensajeExito.style.display = "none";
            }, 5000); // 10000 ms = 10 segundos
        }
    });
</script>

</body>
</html>
