/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalTime;

/**
 *
 * @author USUARIO
 */
public class DisponibilidadMedicaModel {
    
    private int id,id_medico,sede_id,cupo_disponible;
    
    private String nombreSede,nombreDoctor,nombreEspecialidad;
    private Time horaInicio;
    private Time horaFin;
    private Date fecha;

    public DisponibilidadMedicaModel(String nombreSede, String nombreDoctor, String nombreEspecialidad, Time horaInicio, Time horaFin, Date fecha) {
        this.nombreSede = nombreSede;
        this.nombreDoctor = nombreDoctor;
        this.nombreEspecialidad = nombreEspecialidad;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.fecha = fecha;
    }

    public DisponibilidadMedicaModel(int id, String nombreSede, String nombreDoctor, String nombreEspecialidad, Time horaInicio, Time horaFin, Date fecha) {
        this.id = id;
        this.nombreSede = nombreSede;
        this.nombreDoctor = nombreDoctor;
        this.nombreEspecialidad = nombreEspecialidad;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.fecha = fecha;
    }

    
    
    
    
    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getNombreSede() {
        return nombreSede;
    }

    public void setNombreSede(String nombreSede) {
        this.nombreSede = nombreSede;
    }

    public String getNombreDoctor() {
        return nombreDoctor;
    }

    public void setNombreDoctor(String nombreDoctor) {
        this.nombreDoctor = nombreDoctor;
    }

    public String getNombreEspecialidad() {
        return nombreEspecialidad;
    }

    public void setNombreEspecialidad(String nombreEspecialidad) {
        this.nombreEspecialidad = nombreEspecialidad;
    }

    
    
    
    
    public DisponibilidadMedicaModel() {
    }

    public DisponibilidadMedicaModel(int id, int id_medico, int sede_id, int cupo_disponible, Time horaInicio, Time horaFin, Date fecha) {
        this.id = id;
        this.id_medico = id_medico;
        this.sede_id = sede_id;
        this.cupo_disponible = cupo_disponible;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.fecha = fecha;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_medico() {
        return id_medico;
    }

    public void setId_medico(int id_medico) {
        this.id_medico = id_medico;
    }

    public int getSede_id() {
        return sede_id;
    }

    public void setSede_id(int sede_id) {
        this.sede_id = sede_id;
    }

    public int getCupo_disponible() {
        return cupo_disponible;
    }

    public void setCupo_disponible(int cupo_disponible) {
        this.cupo_disponible = cupo_disponible;
    }

    public Time getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Time horaInicio) {
        this.horaInicio = horaInicio;
    }

    public Time getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(Time horaFin) {
        this.horaFin = horaFin;
    }

 
    
    
    
    
}
