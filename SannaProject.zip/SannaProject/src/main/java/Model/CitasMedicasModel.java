/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author USUARIO
 */
import  java.time.LocalDateTime;
public class CitasMedicasModel {
    
    private int id,id_paciente,id_medico,sede_id;
    private String motivo,estado;
    
    private LocalDateTime fechaCita,fecha_registro;

    public CitasMedicasModel() {
    }

    public CitasMedicasModel(int id, int id_paciente, int id_medico, int sede_id, String motivo, String estado, LocalDateTime fechaCita, LocalDateTime fecha_registro) {
        this.id = id;
        this.id_paciente = id_paciente;
        this.id_medico = id_medico;
        this.sede_id = sede_id;
        this.motivo = motivo;
        this.estado = estado;
        this.fechaCita = fechaCita;
        this.fecha_registro = fecha_registro;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_paciente() {
        return id_paciente;
    }

    public void setId_paciente(int id_paciente) {
        this.id_paciente = id_paciente;
    }

    public int getId_medico() {
        return id_medico;
    }

    public void setId_medico(int id_medico) {
        this.id_medico = id_medico;
    }

    public int getSede_id() {
        return sede_id;
    }

    public void setSede_id(int sede_id) {
        this.sede_id = sede_id;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public LocalDateTime getFechaCita() {
        return fechaCita;
    }

    public void setFechaCita(LocalDateTime fechaCita) {
        this.fechaCita = fechaCita;
    }

    public LocalDateTime getFecha_registro() {
        return fecha_registro;
    }

    public void setFecha_registro(LocalDateTime fecha_registro) {
        this.fecha_registro = fecha_registro;
    }
    
    
    
    
    
}
