/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.DisponibilidadMedicaModel;
import Dao.CitasDisponiblesDao;
import java.util.List;
import java.time.format.DateTimeFormatter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpSession;

/**
 *
 * @author USUARIO
 */
@WebServlet(name = "BuscarCitaDisponibleController", urlPatterns = {"/BuscarCitaDisponibleController"})
public class BuscarCitaDisponibleController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    
    response.setContentType("application/json;charset=UTF-8");
    try (PrintWriter out = response.getWriter()) {

    
        HttpSession session = request.getSession();
        String dni = (String) session.getAttribute("dniUsuario");
        
        
    
        int sedeId = Integer.parseInt(request.getParameter("sedeId"));
        int especialidadId = Integer.parseInt(request.getParameter("especialidadId"));
        int doctorId = Integer.parseInt(request.getParameter("doctorId"));

        
        
        
        
  
           HttpSession session1 = request.getSession();
            session.setAttribute("especialidadId_sedeId", sedeId);                    
            session.setAttribute("especialidadId_doctorId", doctorId);
            session.setAttribute("especialidadId_combobox", especialidadId);
            
            
            
            
             
             
        System.out.println("➡ Parámetros recibidos:");
        System.out.println("Sede ID: " + sedeId);
        System.out.println("Especialidad ID: " + especialidadId);
        System.out.println("Doctor ID: " + doctorId);

      
        CitasDisponiblesDao dao = new CitasDisponiblesDao();
        List<DisponibilidadMedicaModel> disponibilidades = dao.listarCitasDisponiblesConSede(sedeId, especialidadId, doctorId);

        
     
        StringBuilder json = new StringBuilder();
        json.append("[");

        int count = 0;


SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // para fecha
DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm"); // para hora

        for (DisponibilidadMedicaModel disp : disponibilidades) {
   
    String fechaFormateada = "";
    Date fechaObj = disp.getFecha(); // suponiendo que devuelve java.util.Date o java.sql.Date
    if (fechaObj != null) {
        fechaFormateada = sdf.format(fechaObj);
    }

  
    java.time.LocalTime inicio = disp.getHoraInicio().toLocalTime();
    String horaFormateada = inicio.format(dtf);

    if (count > 0) json.append(",");

    json.append("{")
        .append("\"fecha\":\"").append(fechaFormateada).append("\",")
        .append("\"hora\":\"").append(horaFormateada).append("\",")
        .append("\"sede\":\"").append(disp.getNombreSede()).append("\",")
    .append("\"idDisponibilidad\":\"").append(disp.getId()).append("\"")
        .append("}");

    count++;
}

        json.append("]");
       System.out.println("JSON generado: " + json.toString());
        out.print(json.toString());
        out.flush();
    }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
