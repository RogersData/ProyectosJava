/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author USUARIO
 */
@WebServlet(name = "ActualizaPcienteV2Controller", urlPatterns = {"/ActualizaPcienteV2Controller"})
public class ActualizarPacienteV2Controller extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        
    response.setContentType("text/html;charset=UTF-8");
    request.setCharacterEncoding("UTF-8");

  
    String idPacienteStr = request.getParameter("id_paciente");
    String nombres = request.getParameter("nombres");
    String apellidos = request.getParameter("apellidos");
    String fechaNacimientoStr = request.getParameter("fecha_nacimiento");
    String sexo = request.getParameter("sexo");
    String direccion = request.getParameter("direccion");
    String telefono = request.getParameter("telefono");
    String email = request.getParameter("email");

   
    if (idPacienteStr == null || nombres == null || apellidos == null || fechaNacimientoStr == null) {
        request.setAttribute("mensaje", "Todos los campos son obligatorios.");
        request.setAttribute("tipoMensaje", "danger");
        request.getRequestDispatcher("actualizarPaciente.jsp").forward(request, response);
        return;
    }

    try {
        
        int idPaciente = Integer.parseInt(idPacienteStr);
        java.sql.Date fechaNacimiento = java.sql.Date.valueOf(fechaNacimientoStr);

        Model.PacienteModel paciente = new Model.PacienteModel();
        paciente.setId_paciente(idPaciente);
        paciente.setNombres(nombres);
        paciente.setApellidos(apellidos);
        paciente.setFecha_nacimiento(fechaNacimiento);
        paciente.setSexo(sexo);
        paciente.setDireccion(direccion);
        paciente.setTelefono(telefono);
        paciente.setEmail(email);

      
        Dao.ActualizarPacienteDao dao = new Dao.ActualizarPacienteDao();
        boolean actualizado = dao.actualizarPaciente(paciente);

     
        if (actualizado) {
            request.setAttribute("mensaje", "✅ Paciente actualizado correctamente.");
            request.setAttribute("tipoMensaje", "success");
        } else {
            request.setAttribute("mensaje", "❌ No se pudo actualizar el paciente.");
            request.setAttribute("tipoMensaje", "danger");
        }

        
        request.setAttribute("paciente", paciente);
        request.getRequestDispatcher("actualizarPaciente.jsp").forward(request, response);

    } catch (Exception e) {
        e.printStackTrace();
        request.setAttribute("mensaje", "❌ Error al procesar la actualización.");
        request.setAttribute("tipoMensaje", "danger");
        request.getRequestDispatcher("actualizarPaciente.jsp").forward(request, response);
    }
		
		
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
