package BD;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class conexionBD {

    private static final String URL = "jdbc:mysql://localhost:3306/sanabd";
    private static final String USUARIO = "root";
    private static final String CLAVE = "admin";
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

    static {
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            System.err.println("Error al cargar el driver MySQL: " + e.getMessage());
        }
    }

    public static Connection conectar() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, CLAVE);
    }

    // Procedimiento con solo parámetros de entrada
    public int ejecutarProcedimiento(String sql, Object[] params) throws SQLException {
        try (Connection conn = conectar(); CallableStatement cs = conn.prepareCall(sql)) {
            for (int i = 0; i < params.length; i++) {
                cs.setObject(i + 1, params[i]);
            }
            return cs.executeUpdate();
        }
    }

    // Procedimiento con parámetro de salida
    public Object ejecutarProcedimientoConSalida(String sql, int tipoDatoSalida) throws SQLException {
        try (Connection conn = conectar(); CallableStatement cs = conn.prepareCall(sql)) {
            cs.registerOutParameter(1, tipoDatoSalida);
            cs.execute();
            return cs.getObject(1); // Devuelve el valor de salida
        }
    }

    // Procedimiento con entrada y salida
    public Object ejecutarProcedimientoInOut(String sql, Object entrada, int tipoDatoSalida) throws SQLException {
        try (Connection conn = conectar(); CallableStatement cs = conn.prepareCall(sql)) {
            cs.setObject(1, entrada);
            cs.registerOutParameter(2, tipoDatoSalida);
            cs.execute();
            return cs.getObject(2); // Devuelve el valor de salida
        }
    }

    // Consulta general
    public ResultSet ejecutarConsulta(String sql) throws SQLException {
        Connection conn = conectar();
        Statement st = conn.createStatement();
        return st.executeQuery(sql);
    }

    // Actualización sin parámetros
    public int ejecutarActualizacion(String sql) throws SQLException {
        try (Connection conn = conectar(); Statement st = conn.createStatement()) {
            return st.executeUpdate(sql);
        }
    }

    // Actualización con parámetros
    public int ejecutarActualizacionP(String sql, Object[] params) throws SQLException {
        try (Connection conn = conectar(); PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            return ps.executeUpdate();
        }
    }
	
	public static void main(String[] args) {
        try {
            Connection conn = conexionBD.conectar();
            if (conn != null && !conn.isClosed()) {
                System.out.println("¡Conexión exitosa a la base de datos!");
                conn.close();
            } else {
                System.out.println("No se pudo establecer la conexión.");
            }
        } catch (Exception e) {
            System.err.println("Error al conectar: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public Object getConexion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}