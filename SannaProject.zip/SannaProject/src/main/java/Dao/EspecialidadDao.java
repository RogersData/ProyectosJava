/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author USUARIO
 */

import BD.conexionBD;
import Model.EspecialidadModel;
import Model.DoctorModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class EspecialidadDao {
    
    conexionBD cn = new conexionBD();
    
    
  public List<EspecialidadModel> obtenerEspecialidadesPorSede(int sedeId) {
    List<EspecialidadModel> lista = new ArrayList<>();
    String sql = "SELECT DISTINCT e.id_especialidad, e.nombre_especialidad " +
                 "FROM especialidades e " +
                 "JOIN medicos m ON e.id_especialidad = m.especialidad_id " +
                 "JOIN disponibilidades_medicas d ON m.id_medico = d.id_medico " +
                 "WHERE d.sede_id = ?";

    try (Connection conn = cn.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
         
        stmt.setInt(1, sedeId);
        try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("id_especialidad");
                String nombre = rs.getString("nombre_especialidad");
                lista.add(new EspecialidadModel(id, nombre));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return lista;
}
    
		
	
   /*Pruebas - -----------------------------------*/
	

	public static void imprimirEspecialidadesPorSede(int sedeId) {
            
    EspecialidadDao especialidadDao = new EspecialidadDao();
    List<EspecialidadModel> especialidades = especialidadDao.obtenerEspecialidadesPorSede(sedeId);

    if (especialidades.isEmpty()) {
        System.out.println("No se encontraron especialidades para la sede con ID: " + sedeId);
    } else {
        System.out.println("Especialidades disponibles para la sede con ID: " + sedeId);
        for (EspecialidadModel esp : especialidades) {
            System.out.println("ID: " + esp.getId_especialidad()+ " - Nombre: " + esp.getNombre_especialidad());
        }
    }
}
 
public static void main(String[] args) {
    imprimirEspecialidadesPorSede(1); 
}
    
}
