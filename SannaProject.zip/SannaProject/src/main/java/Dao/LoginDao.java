/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;
import BD.conexionBD;
import Model.UsuarioModel;
import java.sql.ResultSet;
/**
 *
 * @author USUARIO
 */
public class LoginDao {
    
    int rspta=0;
    String sql="";
    ResultSet rs=null;
    conexionBD cn=new conexionBD();
    public int validarLogin(UsuarioModel tm) throws Exception{
        
          sql="SELECT COUNT(id_usuario) AS cantidad FROM Usuarios WHERE dni='"+tm.getDni()+"' AND clave='"+tm.getClave()+"';";
      /*  sql="SELECT COUNT(CODTRABAJADOR) AS cantidad FROM `trabajador` WHERE USUARIO='"+tm.getUsuario()+"' AND CLAVE='"+tm.getClave()+"'";*/
        rs=cn.ejecutarConsulta(sql);
        while(rs.next()){
            rspta=rs.getInt("cantidad");
        }
    return  rspta;
    }
	
	
	public int obtenerIdUsuarioPorDni(String dni) throws Exception {
    int idUsuario = 0;
    String sql = "SELECT id_usuario FROM Usuarios WHERE dni = '" + dni + "'";
    ResultSet rs = cn.ejecutarConsulta(sql);
    if (rs.next()) {
        idUsuario = rs.getInt("id_usuario");
    }
    return idUsuario;
}
	
	
public int obtenerIdPacientePorIdUsuario(int idUsuario) throws Exception {
    int idPaciente = 0;
    String sql = "SELECT id_paciente FROM Pacientes WHERE id_usuario = " + idUsuario;
    ResultSet rs = cn.ejecutarConsulta(sql);
    if (rs.next()) {
        idPaciente = rs.getInt("id_paciente");
    }
    rs.close();
    return idPaciente;
}
	
    
}
