/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author USUARIO
 */

import BD.conexionBD;

import Model.DisponibilidadMedicaModel;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class CitasDisponiblesDao {
    
    conexionBD cn = new conexionBD();
    
	public List<DisponibilidadMedicaModel> listarCitasDisponiblesConSede(int idSede, int idEspecialidad, int idMedico) {
    List<DisponibilidadMedicaModel> citas = new ArrayList<>();

    String sql = "SELECT dm.id, s.nombre AS nombre_sede, " +
                 "       CONCAT(m.nombres, ' ', m.apellidos) AS nombre_doctor, " +
                 "       e.nombre_especialidad, " +
                 "       dm.fecha, dm.hora_inicio, dm.hora_fin " +
                 "FROM disponibilidades_medicas dm " +
                 "JOIN medicos m ON dm.id_medico = m.id_medico " +
                 "JOIN especialidades e ON m.especialidad_id = e.id_especialidad " +
                 "JOIN sedes s ON dm.sede_id = s.sede_id " +
                 "WHERE dm.sede_id = ? AND m.especialidad_id = ? AND m.id_medico = ? " +
                 "  AND dm.cupo_disponible > 0 " +
                 "ORDER BY dm.fecha, dm.hora_inicio";

    try (Connection conn = cn.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, idSede);
        stmt.setInt(2, idEspecialidad);
        stmt.setInt(3, idMedico);

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            int idDisponibilidad = rs.getInt("id");
            String nombreSede = rs.getString("nombre_sede");
            String nombreDoctor = rs.getString("nombre_doctor");
            String nombreEspecialidad = rs.getString("nombre_especialidad");
            Date fecha = rs.getDate("fecha");
            Time horaInicio = rs.getTime("hora_inicio");
            Time horaFin = rs.getTime("hora_fin");

            DisponibilidadMedicaModel cita = new DisponibilidadMedicaModel(
                nombreSede, nombreDoctor, nombreEspecialidad, horaInicio, horaFin, fecha
            );
            cita.setId(idDisponibilidad); // ← Aquí seteas el ID

            citas.add(cita);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return citas;
}
        
		
		
		
		
	public boolean eliminarCitaDisponiblePorId(int idDisponibilidad) {
    String sql = "DELETE FROM disponibilidades_medicas WHERE id = ?";
    
    try (Connection conn = cn.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        
        stmt.setInt(1, idDisponibilidad);
        int filasAfectadas = stmt.executeUpdate();

        return filasAfectadas > 0; // Retorna true si se eliminó al menos una fila
        
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
        
        
		
	public static void eliminarCitaDisponibilidadYMostrarResultado(int idCita) {
    CitasDisponiblesDao dao = new CitasDisponiblesDao();
    boolean eliminado = dao.eliminarCitaDisponiblePorId(idCita);
    
    if (eliminado) {
        System.out.println("Cita con ID " + idCita + " eliminada correctamente.");
    } else {
        System.out.println("No se pudo eliminar la cita con ID " + idCita + ". Verifica si existe.");
    }
}	
		
       
        
        
        
        
        
	public static void imprimirCitasDisponiblesConSede(int idSede, int idEspecialidad, int idMedico) {
    CitasDisponiblesDao dao = new CitasDisponiblesDao();
    List<DisponibilidadMedicaModel> citas = dao.listarCitasDisponiblesConSede(idSede, idEspecialidad, idMedico);

    if (citas.isEmpty()) {
        System.out.println("No hay citas disponibles para los parámetros proporcionados.");
    } else {
        System.out.println("Citas disponibles:\n");
        for (DisponibilidadMedicaModel cita : citas) {
            System.out.println("ID Disponibilidad: " + cita.getId());
            System.out.println("Sede: " + cita.getNombreSede());
            System.out.println("Doctor: " + cita.getNombreDoctor());
            System.out.println("Especialidad: " + cita.getNombreEspecialidad());
            System.out.println("Fecha: " + cita.getFecha());
            System.out.println("Hora inicio: " + cita.getHoraInicio());
            System.out.println("Hora fin: " + cita.getHoraFin());
            System.out.println("----------------------------------");
        }
    }
    
    
    
}
        
 public static void main(String[] args) {
    int idSede = 1;
    int idEspecialidad = 1;
    int idMedico = 1;

    imprimirCitasDisponiblesConSede(idSede, idEspecialidad, idMedico);

    // Ejemplo para eliminar una cita con ID 3
    eliminarCitaDisponibilidadYMostrarResultado(10);
}       
 

}
