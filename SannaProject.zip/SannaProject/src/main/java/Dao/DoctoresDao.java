/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import BD.conexionBD;

import Model.DoctorModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class DoctoresDao {
    
    
    conexionBD cn = new conexionBD();
    
    public List<DoctorModel> obtenerDoctoresPorEspecialidadYSede(int idEspecialidad, int idSede) {
    List<DoctorModel> listaDoctores = new ArrayList<>();

    String sql = "SELECT DISTINCT m.id_medico, m.id_usuario, m.nombres, m.apellidos, " +
                 "m.especialidad_id, m.telefono, m.email " +
                 "FROM medicos m " +
                 "JOIN disponibilidades_medicas dm ON m.id_medico = dm.id_medico " +
                 "WHERE m.especialidad_id = ? AND dm.sede_id = ?";

    try (Connection conn = cn.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        
        stmt.setInt(1, idEspecialidad);
        stmt.setInt(2, idSede);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            int idMedico = rs.getInt("id_medico");
            int idUsuario = rs.getInt("id_usuario");
            String nombres = rs.getString("nombres");
            String apellidos = rs.getString("apellidos");
            int especialidadId = rs.getInt("especialidad_id");
            String telefono = rs.getString("telefono");
            String email = rs.getString("email");

            DoctorModel doctor = new DoctorModel(idMedico, idUsuario, especialidadId, nombres, apellidos, telefono, email);
            listaDoctores.add(doctor);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return listaDoctores;
}
  
    
    
	
    public static void main(String[] args) {
    DoctoresDao dao = new DoctoresDao();

    
    int especialidadId = 1;
    int sedeId = 1;

    List<DoctorModel> doctores = dao.obtenerDoctoresPorEspecialidadYSede(especialidadId, sedeId);

    if (doctores.isEmpty()) {
        System.out.println("No se encontraron doctores para la especialidad " + especialidadId + " y sede " + sedeId);
    } else {
        System.out.println("Doctores encontrados:");
        for (DoctorModel doctor : doctores) {
            System.out.println("ID Médico: " + doctor.getId_medico());
            System.out.println("Nombre: " + doctor.getNombres() + " " + doctor.getApellidos());
            System.out.println("Teléfono: " + doctor.getTelefono());
            System.out.println("Email: " + doctor.getEmail());
            System.out.println("-------------");
        }
    }
}
    
    
    
  
        
}
