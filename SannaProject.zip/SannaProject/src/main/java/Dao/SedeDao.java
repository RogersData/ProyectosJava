/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author USUARIO
 */


import BD.conexionBD;
import Model.EspecialidadModel;
import Model.DoctorModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Model.SedeModel;
public class SedeDao {
    
    conexionBD cn = new conexionBD();
    
    
      public List<SedeModel> obtenerTodasLasSedes() {
        List<SedeModel> lista = new ArrayList<>();
        String sql = "SELECT sede_id, nombre, direccion, telefono, ciudad FROM sedes";

        try (Connection conn = cn.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("sede_id");
                String nombre = rs.getString("nombre");
                String direccion = rs.getString("direccion");
                String telefono = rs.getString("telefono");
                String ciudad = rs.getString("ciudad");

                SedeModel sede = new SedeModel(id, nombre, direccion, telefono, ciudad);
                lista.add(sede);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener sedes: " + e.getMessage());
        }

        return lista;
    }
      
      
      
    
}
