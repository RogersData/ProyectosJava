/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import BD.conexionBD;
import Model.PacienteModel;
import Model.UsuarioModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RegistroPacienteDao {
    
    int rspta = 0;
    String sql = "";
    ResultSet rs = null;
    conexionBD cn = new conexionBD();
    
    
    public boolean registrarUsuarioYPaciente(UsuarioModel usuario, PacienteModel paciente) throws Exception {
    int idUsuario = registrarUsuario(usuario); // Insertas el usuario

    if (idUsuario > 0) {
        paciente.setId_usuario(idUsuario); // Asignas el ID al paciente
        
        return registrarPaciente(paciente,idUsuario); // Insertas el paciente
    } else {
        return false;
    }
}
   
    
    
    public int registrarUsuario(UsuarioModel tm) throws Exception {
        sql = "INSERT INTO Usuarios (dni, clave, rol) VALUES ('" + tm.getDni() + "', '" + tm.getClave() + "', 'Paciente');";
        Statement st = cn.conectar().createStatement();
        rspta = st.executeUpdate(sql); // Devuelve 1 si se insertó correctamente
             
       if (rspta > 0) {
        // Si se insertó correctamente, obtener el id_usuario
        int idUsuario = obtenerIdUsuarioPorDni(tm.getDni());
        return idUsuario;  // Devuelvo el id_usuario en lugar de rspta
    } else {
        return -1; // No se insertó
    }
	
    }
    
    
    
        public int obtenerIdUsuarioPorDni(String dni) throws Exception {
        int idUsuario = -1; // Valor por defecto si no encuentra nada
        String sql = "SELECT id_usuario FROM Usuarios WHERE dni = ?";

        try (PreparedStatement pst = cn.conectar().prepareStatement(sql)) {
            pst.setString(1, dni);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    idUsuario = rs.getInt("id_usuario");
                
                }
            }
        }

        return idUsuario;
    }
	
	
	
	public boolean registrarPaciente(PacienteModel paciente, int idUsuario) throws SQLException {
    String sql = "INSERT INTO Pacientes (" +
                 "id_usuario, nombres, apellidos, fecha_nacimiento, sexo, direccion, telefono, email" +
                 ") VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    try (Connection conn = cn.conectar();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setInt(1, idUsuario);
        pst.setString(2, paciente.getNombres());
        pst.setString(3, paciente.getApellidos());
        pst.setDate(4, paciente.getFecha_nacimiento()); // Asegúrate que sea java.sql.Date
        pst.setString(5, paciente.getSexo());
        pst.setString(6, paciente.getDireccion());
        pst.setString(7, paciente.getTelefono());
        pst.setString(8, paciente.getEmail());

        int filasInsertadas = pst.executeUpdate();
        return filasInsertadas > 0;
    }
}

 



}
