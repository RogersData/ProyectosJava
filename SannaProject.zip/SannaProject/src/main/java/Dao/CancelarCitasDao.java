/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author USUARIO
 */
import Model.CitasMedicasModel;
import java.util.List;
import BD.conexionBD;
import Model.CitasMedicaModelPacienteModel;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;



import java.util.ArrayList;
import java.util.List;

public class CancelarCitasDao {
     conexionBD cn = new conexionBD();
    
	
	public List<CitasMedicaModelPacienteModel> listarCitasPendientesYConfirmadasPorPaciente(int idPaciente) {
    List<CitasMedicaModelPacienteModel> citas = new ArrayList<>();

    String sql = "SELECT c.id, p.nombres AS nombre_paciente, p.apellidos AS apellido_paciente, "
               + "m.nombres AS nombre_medico, m.apellidos AS apellido_medico, "
               + "e.nombre_especialidad, s.nombre AS nombre_sede, c.fecha_cita, c.estado "
               + "FROM citas_medicas c "
               + "JOIN pacientes p ON c.id_paciente = p.id_paciente "
               + "JOIN medicos m ON c.id_medico = m.id_medico "
               + "JOIN especialidades e ON m.especialidad_id = e.id_especialidad "
               + "JOIN sedes s ON c.sede_id = s.sede_id "
               + "WHERE c.id_paciente = ? AND c.estado IN ('Pendiente', 'Confirmada') "
               + "ORDER BY c.fecha_cita ASC";

    try (Connection conn = cn.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, idPaciente);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            int idCita = rs.getInt("id");
            String nombrePaciente = rs.getString("nombre_paciente");
            String apellidoPaciente = rs.getString("apellido_paciente");
            String nombreMedico = rs.getString("nombre_medico");
            String apellidoMedico = rs.getString("apellido_medico");
            String especialidad = rs.getString("nombre_especialidad");
            String nombreSede = rs.getString("nombre_sede");
            LocalDateTime fechaCita = rs.getTimestamp("fecha_cita").toLocalDateTime();
            String estado = rs.getString("estado");

            CitasMedicaModelPacienteModel cita = new CitasMedicaModelPacienteModel(
                nombrePaciente, apellidoPaciente,
                nombreMedico, apellidoMedico,
                especialidad, estado, nombreSede,
                idCita, fechaCita
            );

            citas.add(cita);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return citas;
}

/*
public boolean eliminarCitaPorId(int idCita) {
    String sql = "DELETE FROM citas_medicas WHERE id = ?";

    try (Connection conn = cn.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, idCita);
        int rowsAffected = stmt.executeUpdate();
        return rowsAffected > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

*/

public boolean cancelarCitaPorId(int idCita) {
    String sql = "UPDATE citas_medicas SET estado = 'Cancelada' WHERE id = ? AND estado IN ('Pendiente', 'Confirmada')";

    try (Connection conn = cn.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, idCita);
        int rowsAffected = stmt.executeUpdate();
        return rowsAffected > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
	
	
	public void imprimirCitasPendientesYConfirmadasPorPaciente(int idPaciente) {
    List<CitasMedicaModelPacienteModel> citas = listarCitasPendientesYConfirmadasPorPaciente(idPaciente);

    if (citas.isEmpty()) {
        System.out.println("El paciente con ID " + idPaciente + " no tiene citas Pendientes ni Confirmadas.");
    } else {
        System.out.println("Citas Pendientes y Confirmadas del paciente con ID: " + idPaciente);
        System.out.println("------------------------------------------------------------------------------------------");
        System.out.printf("%-6s %-20s %-20s %-20s %-15s %-20s %-12s\n",
                "ID", "Paciente", "Médico", "Especialidad", "Sede", "Fecha", "Estado");
        System.out.println("------------------------------------------------------------------------------------------");

        for (CitasMedicaModelPacienteModel cita : citas) {
            String nombrePacienteCompleto = cita.getNombrePaciente() + " " + cita.getApellidoPaciente();
            String nombreMedicoCompleto = cita.getNombreMedico() + " " + cita.getApellidoMedico();
            System.out.printf("%-6d %-20s %-20s %-20s %-15s %-20s %-12s\n",
                    cita.getIdCita(),
                    nombrePacienteCompleto,
                    nombreMedicoCompleto,
                    cita.getEspecialidadNombre(),
                    cita.getNombreSede(),
                    cita.getFechaCita().toString(), 
                    cita.getEstado());
        }
    }
}
/*
public static void main(String[] args) {
    CancelarCitasDao dao = new CancelarCitasDao();

    int idCitaParaEliminar = 5; 

    boolean eliminado = dao.eliminarCitaPorId(idCitaParaEliminar);

    if (eliminado) {
        System.out.println("La cita con ID " + idCitaParaEliminar + " fue eliminada correctamente.");
    } else {
        System.out.println("No se pudo eliminar la cita con ID " + idCitaParaEliminar + ". Puede que no exista.");
    }
}*/
}
