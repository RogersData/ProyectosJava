/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

/**
 *
 * @author USUARIO
 */

import BD.conexionBD;

import Model.PacienteModel;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class ActualizarPacienteDao {
    conexionBD cn = new conexionBD();
    
    
    public PacienteModel obtenerPacientePorDni(String dni) {
    PacienteModel paciente = null;
    String sql = "SELECT p.id_paciente, p.id_usuario, p.nombres, p.apellidos, p.fecha_nacimiento, p.sexo, p.direccion, p.telefono, p.email " +
                 "FROM Pacientes p " +
                 "JOIN Usuarios u ON p.id_usuario = u.id_usuario " +
                 "WHERE u.dni = ?";

    try (Connection conn = cn.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, dni);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            paciente = new PacienteModel();
            paciente.setId_paciente(rs.getInt("id_paciente"));
            paciente.setId_usuario(rs.getInt("id_usuario"));
            paciente.setNombres(rs.getString("nombres"));
            paciente.setApellidos(rs.getString("apellidos"));
            paciente.setFecha_nacimiento(rs.getDate("fecha_nacimiento"));
            paciente.setSexo(rs.getString("sexo"));
            paciente.setDireccion(rs.getString("direccion"));
            paciente.setTelefono(rs.getString("telefono"));
            paciente.setEmail(rs.getString("email"));
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return paciente;
}

    
 public boolean actualizarPaciente(PacienteModel paciente) {
    String sql = "UPDATE Pacientes SET nombres = ?, apellidos = ?, fecha_nacimiento = ?, sexo = ?, direccion = ?, telefono = ?, email = ? WHERE id_paciente = ?";

    try (Connection conn = cn.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, paciente.getNombres());
        stmt.setString(2, paciente.getApellidos());
        stmt.setDate(3, paciente.getFecha_nacimiento()); 
        stmt.setString(4, paciente.getSexo());
        stmt.setString(5, paciente.getDireccion());
        stmt.setString(6, paciente.getTelefono());
        stmt.setString(7, paciente.getEmail());
        stmt.setInt(8, paciente.getId_paciente());

        int filasActualizadas = stmt.executeUpdate();
        return filasActualizadas > 0;

    } catch (SQLException e) {
        e.printStackTrace(); 
        return false;
    }
}   
    
    
    public static void main(String[] args) {
    ActualizarPacienteDao dao = new ActualizarPacienteDao();

    
    PacienteModel paciente = new PacienteModel();
    paciente.setId_paciente(1); 
    paciente.setNombres("Carlos");
    paciente.setApellidos("Ramírez");
    paciente.setFecha_nacimiento(java.sql.Date.valueOf("1985-10-20")); // formato yyyy-MM-dd
    paciente.setSexo("M");
    paciente.setDireccion("Av. Siempre Viva 742");
    paciente.setTelefono("987123456");
    paciente.setEmail("carlos.ramirez@example.com");

    // Intentar actualizar
    boolean resultado = dao.actualizarPaciente(paciente);

    
    if (resultado) {
        System.out.println("✅ Paciente actualizado correctamente.");
    } else {
        System.out.println("❌ Error al actualizar el paciente.");
    }
}
    
    
   
    
public static void mostrarPacientePorDni(String dni) {
    ActualizarPacienteDao dao = new ActualizarPacienteDao();
    PacienteModel paciente = dao.obtenerPacientePorDni(dni);

    if (paciente != null) {
        System.out.println("Datos del paciente:");
        System.out.println("ID Paciente: " + paciente.getId_paciente());
        System.out.println("ID Usuario: " + paciente.getId_usuario());
        System.out.println("Nombres: " + paciente.getNombres());
        System.out.println("Apellidos: " + paciente.getApellidos());
        System.out.println("Fecha de nacimiento: " + paciente.getFecha_nacimiento());
        System.out.println("Sexo: " + paciente.getSexo());
        System.out.println("Dirección: " + paciente.getDireccion());
        System.out.println("Teléfono: " + paciente.getTelefono());
        System.out.println("Email: " + paciente.getEmail());
    } else {
        System.out.println("No se encontró paciente con DNI: " + dni);
    }
}



/*
public static void main(String[] args) {
    mostrarPacientePorDni("70056693"); // Cambia por un DNI válido
}*/
}


