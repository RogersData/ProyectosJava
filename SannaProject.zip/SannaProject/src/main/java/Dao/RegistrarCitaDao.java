/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import BD.conexionBD;

/**
 *
 * @author USUARIO
 */
import Model.DisponibilidadMedicaModel;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;


public class RegistrarCitaDao {
    
	conexionBD cn = new conexionBD();
	
	public boolean registrarCitaMedica(int idPaciente, int idMedico, int sedeId, java.sql.Timestamp fechaCita, String motivo) {
    String sql = "INSERT INTO citas_medicas (id_paciente, id_medico, sede_id, fecha_cita, motivo) " +
                 "VALUES (?, ?, ?, ?, ?)";

    try (Connection conn = cn.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, idPaciente);
        stmt.setInt(2, idMedico);
        stmt.setInt(3, sedeId);
        stmt.setTimestamp(4, fechaCita);
        stmt.setString(5, motivo);

        int filasAfectadas = stmt.executeUpdate();
        return filasAfectadas > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}


}
